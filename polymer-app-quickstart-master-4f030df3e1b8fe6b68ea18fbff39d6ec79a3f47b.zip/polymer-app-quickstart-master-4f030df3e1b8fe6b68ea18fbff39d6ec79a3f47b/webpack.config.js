module.exports = require('./config/webpack');
