const path = require('path');
const root = path.join(__dirname, '../');

const distPath = path.join(root, '__dist');
const servicePath = path.join(distPath, 'service');

const publicPath = './';
const testPath = path.join(root, '__test');

module.exports = {distPath, publicPath, servicePath, testPath};
