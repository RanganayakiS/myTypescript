const path = require('path');
const servicePath = path.join(__dirname, "../src/service");
const root = (__path) => path.join(servicePath, __path);

const services = {
    sampleService: root('sampleService')
};

module.exports = {services};
