const {publicPath, testPath} = require("../shared");
const {root} = require('../entries');

module.exports = {
    output: {
        filename: 'spec.js',
        path: testPath,
        publicPath
    },
    devtool: 'inline-source-map',
    module: {
        rules: [
            {
                enforce: 'pre',
                test: /\.ts$/,
                include: [root('../src')],
                loader: 'tslint-loader',
                exclude: /node_modules/
            },
            {
                enforce: "pre",
                test: /\.js$/,
                loader: "source-map-loader"
            },
            {
                enforce: "pre",
                test: /\.ts$/,
                use: "source-map-loader"
            },
            {
                test: /\.ts$/,
                include: [root('../src')],
                loader: 'awesome-typescript-loader',
                exclude: /node_modules/
            },
            {
                test: /\.html$/, // handles html files. <link rel="import" href="path.html"> and import 'path.html';
                loader: 'wc-loader'
            }
        ]
    },
    resolve: {
        extensions: ['.js', '.ts', '.json']
    }
};
