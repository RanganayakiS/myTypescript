const {distPath, publicPath, servicePath} = require("../shared");
const {root, entries:entry} = require("../entries");
const {services} = require("../services");


const webpack = require("webpack");

module.exports = {
    entry: services,
    output: {
        filename: "[name].js",
        path: servicePath,
        publicPath
    },
    resolve: {
        extensions: [".ts", ".js", ".json"]
    },
    module: {
        rules: [
            // {
            //     enforce: "pre",
            //     test: /\.ts$/,
            //     include: [root("../src")],
            //     loader: "tslint-loader",
            //     exclude: /node_modules/
            // },
            {
                enforce: "pre",
                test: /\.js$/,
                loader: "source-map-loader"
            },
            {
                enforce: "pre",
                test: /\.ts$/,
                use: "source-map-loader"
            },
            {
                test: /\.ts$/,
                include: [root("../src/service/")],
                loader: "awesome-typescript-loader",
                exclude: /node_modules/
            },
        ]
    },
    plugins: [

    ]
};
