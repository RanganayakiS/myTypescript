///<reference path="../api/appServer/AppServer.ts"/>
import Promise = require("bluebird");
import {AppEngineServiceBase} from "./helpers/serviceCreator/AppServerServiceBase";
import serviceCreator from "./helpers/serviceCreator/serviceCreator";
import {ICompanyData} from "../common/model/ICompanyData";
import CompanyGenerator from "../common/utilities/CompanyGenerator";
import {Thenable} from "bluebird";
import UdfHelper from "./helpers/udfHelper/UdfHelper";
import IAppServerContext = AppServer.IAppServerContext;

interface IUdfRequest {
    method: string,
    data: string
}

class SampleService extends AppEngineServiceBase {
    private udf: string;
    private uuid: string;
    private env: string;
    private actions: { [id: string]: (requestData: any) => any };

    constructor() {
        super("SampleService");
        this.actions = {
            "sampleDataRequest": (r) => { return this.sampleDataRequest(r) },
            "udfRequest": (r) => { return this.udfRequest(<IUdfRequest> r) }
        }
    }

    public onInit(context: IAppServerContext) {
        this.uuid = context.getUUID();
        this.env = context.dataCenter.toLowerCase();
        if (this.env == "dev") {
            this.udf = context.getConfiguration("udf") + "?reutersuuid=" + this.uuid;
        } else {
            this.udf = context.getConfiguration("udf");
        }
    }

    public sampleDataRequest(requestData: any): ICompanyData[] {
        return CompanyGenerator.generate(5);
    }

    public udfRequest (requestData: IUdfRequest): Thenable<ICompanyData[]>{
        console.log("ADC REQUEST");
        console.log(this.udf);
        console.log(this.uuid);
        return UdfHelper.request(this.udf, this.uuid, requestData.method, requestData.data);
    }

    public getActions(): { [id: string]: (requestData: any) => Thenable<any> } {
        return this.actions;
    }
}

module.exports = serviceCreator(new SampleService());