///<reference path="../../../api/udf/UDF.ts"/>
import Promise = require("bluebird");
import request = require("request");
import IUdfRequest = UDF.IUdfRequest;
import {Globals} from "../../../common/constants/Globals";

const postAsync: any = Promise.promisify(request.post, {multiArgs: true});

export default class UdfHelper {
    public static request<T, U>(url: string, reutersuuid: string, method: string, data: T): Promise<U> {
        console.log("Udf request");
        console.log(url);
        let udfRequest: IUdfRequest<T> = {
            Entity: {
                E: method,
                W: data
            }
        };

        let postRequest = {
            url,
            headers: {
                reutersuuid,
                "X-Tr-Applicationid": "ekn.app." + Globals.ApplicationName
            },
            proxy: "http://127.0.0.1:8888",
            body: JSON.stringify(udfRequest)
        };

        return postAsync(postRequest)
            .then((res) => {
                return <U> res;
            });
    }
}