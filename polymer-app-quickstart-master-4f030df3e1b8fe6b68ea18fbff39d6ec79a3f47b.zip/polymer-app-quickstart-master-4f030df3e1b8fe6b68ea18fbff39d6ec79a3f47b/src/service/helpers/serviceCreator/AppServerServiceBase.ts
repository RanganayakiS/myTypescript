///<reference path="../../../api/appServer/AppServer.ts"/>
import Promise = require("bluebird");
import {Thenable} from "bluebird";
import IAppEngineService = AppServer.IAppEngineService;
import IAppServerContext = AppServer.IAppServerContext;
import IAppServerPayload = AppServer.IAppServerPayload;

interface IAppEngineCallback {
    (error, response): void;
}

export abstract class AppEngineServiceBase implements IAppEngineService {
    private logger: Console;
    private typeName: string;
    constructor(typeName: string) {
        this.typeName = typeName;
        this.logger = console;
    }

    public service = (context: IAppServerContext, payload: IAppServerPayload<any>, callback: IAppEngineCallback): void => {
        this.onInit(context);
        this.processRequest(context, payload, callback);
    };

    private failWith(context: IAppServerContext, callback: IAppEngineCallback, message: string, exception: any = null) {
        let env = context.dataCenter.toUpperCase();

        if (exception) {
            this.logger.error(message, exception);
        } else {
            this.logger.error(message);
        }

        let response = {
            errorMessage: message,
            exception: null
        };

        let isSendErrorDetails = ["DEV", "ALPHA"].indexOf(env) >= 0;

        if (isSendErrorDetails && exception) {
            if (exception instanceof Error) {
                response.exception = exception.message + "\r\n" + exception.stack;
            } else {
                response.exception = exception;
            }
        }

        callback(null, response);
    };

    private processRequest(context: IAppServerContext, payload: IAppServerPayload<any>, callback: IAppEngineCallback) {
        let action = payload.action;

        this.logger.debug("Proceesing request");

        let actions = this.getActions();
        if (!action) {
            this.failWith(context, callback, "No action specified");
        } else if (action in actions) {
            this.logger.debug(`${this.typeName}.${action}`);

            Promise.resolve(actions[action](payload.data))
            .then((result) => {
                this.logger.debug(`${this.typeName}.${action} successfully done`);
                callback(null, result);
            }).catch((error) => {
                this.logger.debug(`${this.typeName}.${action} faield!`);
                this.failWith(context, callback, "Action " + action + " failed", error);
            });
        } else {
            this.failWith(context, callback, "Unsupported action " + action);
        }
    };

    public abstract onInit(context: IAppServerContext);

    public abstract getActions(): { [id: string]: (requestData: any) => Thenable<any> };
}