///<reference path="../../../api/appServer/AppServer.ts"/>
import IAppEngineService = AppServer.IAppEngineService;

let serviceCreator = (serviceInstance: IAppEngineService) => {
    let service = function() {
    };
    service.prototype = serviceInstance;
    return service;
};
export default serviceCreator;