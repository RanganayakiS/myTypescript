namespace ELF {
    // TODO: specify interfaces

    /** 
     * Emerald Autosuggest element: emerald-autosuggest
     */ 
    export interface EmeraldAutosuggest<T> extends HTMLElement{
        adapter: any;
        autoSelectDisabled: boolean;
        context: string;
        country: string;
        disabled: boolean;
        fieldMapping: any;
        moreSearchDisabled: boolean;
        moreSearchText: string;
        portfolioId: string;
        profile: string;
        ric: string;
        hideSuggestions(): void;
        setAdapter(adapter: any);
        setInput(inputElement: HTMLInputElement): void;
        setTransformer(transformer: (data: IEmeraldAutosuggestData<T>) => IEmeraldAutosuggestData<T>): void;
        showSuggestions(): void;
        addEventListener(id: string, handler: EmeraldAutosuggestEventHandler<T>); // Incompatible with ES6
    }


    export interface EmeraldAutosuggestEventHandler<T> {
        (e: IEmeraldAutosuggestEvent<T>): void;
    }

    export interface IEmeraldAutosuggestEvent<T> extends Event{
        detail: {
            item: {
                value: IEmeraldAutosuggestValue<T>
            }
        }
    }

    export interface IEmeraldAutosuggestData<T> {
        header: any;
        params: any;
        searchUrl: string,
        suggestions: IEmeraldAutosuggestSuggestion<T>[]
    }

    export interface IEmeraldAutosuggestSuggestion<T> {
        highlighted: boolean;
        label: string;
        value: IEmeraldAutosuggestValue<T>
    }

    export interface IEmeraldAutosuggestValue<T> {
        ac: string[];
        cmd: string;
        fr: boolean;
        id: number;
        meta: any;
        navigation: any;
        p: T;
        position: number;
        relations: any;
        s: string;
        score: number;
        significance: number;
        source: string;
        st: string;
        subtitle: string;
        symbol: string;
        title: string;
        vc: string;
    }

    export interface IAutosuggestResultRic {
        PermID: string
        RIC: string
    }

    //https://thehub.thomsonreuters.com/docs/DOC-635233
    export interface IAutosuggestResultField {
        Rank: number,
        fdt: string,
        fid: string,
        fimo: boolean,
        firp: boolean,
        firt: boolean,
        fl: string,
        fn: string,
        fsrc: string,
        fsrnk: number
    }

    /** 
     * Emerald Nav Bar element: emerald-nav-bar
     */  

    export interface EmeraldNavBar extends HTMLElement{
        data: IEmeraldNavBarElement[];
        noCompact: boolean;
    }

    export interface IEmeraldNavBarElement extends ICoralListElement{
        navigation?: IEikonNavigation;
    }

    /**
     * Emerald Popup Menu element: emerald-popup-menu
     */
    type AttachPoint =  "top" | "top-left" | "top-right" | "left" |
                        "center" | "right" | "bottom" | "bottom-left" |
                        "bottom-right" | "auto";

    type TransitionStyle =  "fade" | "zoom" | "slide-down" | "slide-up" |
                            "slide-right" | "slide-left" | "slide-right-down" | "slide-right-up" |
                            "slide-left-down" | "slide-left-up" | null;
    export interface EmeraldPopupMenu extends HTMLElement{
        attachPoint: AttachPoint;
        autoReposition: boolean;
        autoResize: boolean;
        data: ICoralListElement[];
        height: string;
        popupMargin: string;
        target: HTMLElement | any;
        targetAttachPoint: AttachPoint;
        transition: TransitionStyle
        width: string;
        clearAllSelectedItems(): void;
        clearHighlightedItem(): void;
        getPopup(): HTMLElement;
        hide(): void;
        highlightItem(item: HTMLElement): void;
        highlightItemById(id: string): void;
        highlightItemByIndex(index: number);
        isShown(): boolean;
        selectItem(item: HTMLElement): void;
        selectItemById(id: string): void;
        selectItemByIndex(index: string): void;
        show(): void;
        update(): void;
    }

    /** 
     * Coral list element: coral-list
     */

    export interface CoralList extends HTMLElement {
        data: ICoralListElement[];
        height: number;
        maxHeight: number;
        addItem(itemModel: ICoralListElement, optIndex?: number);
        getItemById(id: string): ICoralListElement;
        getItemByIndex(index: number): ICoralListElement;
        getItemIndex(item: ICoralListElement): number;
        getItems(): ICoralListElement[];
        removeItemById(id: string): void;
        removeItemByIndex(index: number): void;
        setItemRenderer(renderer: ICoralListRenderer): void
    }

    export interface ICoralListElement {
        id?: string;
        label: string;
        value?: string | Object; 
        type?: CoralListItemType;
        renderer?: (item: ICoralListElement) => string;
        disabled?: boolean;
        readonly?: boolean;
        hidden?: boolean;
        selected?: boolean;
    }

    export interface ICoralListRenderer {
        (item: ICoralListElement): string
    }

    type CoralListItemType = "default" | "header" | "divider";

    /**
     * Coral dialog element: coral-dialog
     */

    export interface CoralDialog extends HTMLElement {
        autoHide: boolean;
        header: string;
        height: string;
        id: string;
        modal: boolean;
        noCancel: boolean;
        noDragging: boolean;
        noOk: boolean;
        width: string;
        zIndex: string;
        getCancelButton(): HTMLElement;
        getOkButton(): HTMLElement;
        getPopupPanel(): HTMLElement;
        hide(): void;
        setContent(html: string|HTMLElement);
        setFooterContent(html: string|HTMLElement);
        show(): void;
    }

    export interface ICoralDialogEventData {
        action: "show" | "cancel" | "confirm"
        type: string
    }

    /**
     * Amber notification element: amber-notification
     */

    export interface AmberNotification extends HTMLElement {
        clear(): void;
        confirm(...args: (string|HTMLElement|Array<string|HTMLElement>)[]): void;
        error(...args: (string|HTMLElement|Array<string|HTMLElement>)[]): void;
        info(...args: (string|HTMLElement|Array<string|HTMLElement>)[]): void;
        warn(...args: (string|HTMLElement|Array<string|HTMLElement>)[]): void;
    }

    /**
     * Common interfaces
     */

    export interface IEikonNavigation {
        url?: string;
        name?: string
        target?: "popup" | "replace" | "tab";
        entities: IEikonNavigationEntity[]
    }

    export interface IEikonNavigationEntity {
        RIC?: string;
        NewsQuery?: string;
    }
}