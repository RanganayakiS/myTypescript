namespace Polymer {
    export interface HTMLDomRepeatElement extends HTMLElement {
        render(): void;
    }
}