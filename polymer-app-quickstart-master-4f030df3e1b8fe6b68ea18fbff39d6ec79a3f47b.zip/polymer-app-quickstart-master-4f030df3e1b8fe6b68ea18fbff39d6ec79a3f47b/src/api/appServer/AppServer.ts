namespace AppServer {
    type CacheType = "redis" | "cassandra";
    type LogLevel = "debug" | "info" | "warn" | "error";

    export interface IAppServerContextCacheArgs {
        type: CacheType;
    }

    export interface IAppServerPayload<T> {
        action: string;
        data?: T;
    }

    export interface IAppServerContext {
        name: string;
        version: string;
        dataCenter: string;
        getPayload(): any;
        getUUID(): string;
        getConfiguration(key: string): string;
        getCache(args: IAppServerContextCacheArgs): any;
        callService(serviceName: string, method: string, input: any, callback: any, options: any);
        logLevel(level: LogLevel, msg: string, meta: any);
        log(msg: string, meta: any);
        warn(msg: string, meta: any);
        error(msg: string, meta: any);
        getLogger(msg: string, meta: any);
        logFeatureHit(feature: string);
    }

    export interface IAppEngineService {
        service(context: any, payload: any, callback: any): void;
        getActions(): { [id: string]: (requestData: any) => any }
    }
}