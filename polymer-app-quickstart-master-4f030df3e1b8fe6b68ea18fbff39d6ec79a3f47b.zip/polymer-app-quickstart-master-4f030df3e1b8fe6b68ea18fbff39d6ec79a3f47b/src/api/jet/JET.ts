namespace JET {
    interface IContainerDescription {
        properties: any[];
    }

    interface INavigateOptions {
        target?: string;
        url?: string;
    }

    interface IAppConfig {
        ID?: string;
        Title?: string;
        Context?: any;
    }

    export interface IJet2Api {
        setAttribute(name: any, value: any): void;
        contextMenu(menu: Object): void;
    }

    export interface IJetApi {
        ContainerDescription: IContainerDescription
        /**
         * Register AppHit
         *
         * @param appName The name of your application. It must be a string not exceeding 40 characters. 
         * @param subProduct If your app in an app on the AppServer, the subProduct should be "app". For more information of subProduct, please see https://thehub.thomsonreuters.com/docs/DOC-645075
         * @param feature The feature of your application that you are tracking. It must be a string not exceeding 40 characters. 
         */
        appHit(appName: string, subProduct: string, feature: string): void;

        onLoad(action: () => void): void;
        onLoadFailed(action: () => void): void;

        init(config: IAppConfig): void;

        loggingSource(src: string): void;
        debug(msg: string): void;
        information(msg: string): void;
        warning(msg: string): void;
        high(msg: string): void;
        critical(msg: string): void;
        onLoad(handler: (isArchiveLoaded: boolean) => void, plugins?: string[]): void;

        resizeTo(width: number, height: number, inner?: boolean);
        navigate(options: INavigateOptions);
        contextChange(data: any);

        Archive: IJetArchive;
        Quotes2: IJetQuotes;
        Settings: IJetSettings;
    }

    export interface IJetQuotes {
        create(): IJetSubscription;
    }

    export interface IJetSubscription {
        addRic(ric: string, subId?: string): string;
        addFields(fields: string[]): void;
        addEventListener(type: string, handler: EventListenerHandler): void;
        removeAllEventListeners(): void;
        start(): void;
        stop(): void;
        dispose(): void;
        removeRic(subId: string): void;
        removeFields(fields: string[]): void;
        pauseOnDeactivate(isPausedOnDeactivate: boolean): void;
    }

    export type EventListenerHandler = (options: IEventListenerHandlerOptions) => void;

    export interface IEventListenerHandlerOptions {
        ric: string;
        subId: string;
        type?: string;
        values: {
            [field: string]: number | string
        };
    }

    export interface IJetReadingSettingInfo {
        providerName: string;
        settingName: string;
        expandValue?: boolean;
    }

    export interface IJetWritingSettingInfo {
        providerName: string;
        settingName: string;
        settingValue: string;
    }

    export interface IJetReadingSettingCallback {
        (value: string): void
    }

    export interface IJetReadingErrorCallback {
        (msg: string): void
    }

    export interface IJetChangeSettingInfo {
        providerName: string;
        settingName: string;
    }

    export interface IJetChangeSettingInfo {
        providerName: string;
        settingName: string;
        oldValue?: string;
        newValue?: string;
    }

    export interface IJetOnChangeSettingCallback {
        (value: IJetChangeSettingInfo): void
    }

    export interface IJetSettings {
        read(handler: IJetReadingSettingCallback, data: IJetReadingSettingInfo, errorHandler?: IJetReadingErrorCallback): void;
        write(data: IJetWritingSettingInfo): void;
        onChange(handler: IJetOnChangeSettingCallback, data: IJetChangeSettingInfo): void;
    }

    export interface IJetArchive {
        getAllKeys(): string[];
        get(key: string, defaultValue?: string): string;
        put(key: string, item?: string): boolean;
        clear(): void;
    }
}