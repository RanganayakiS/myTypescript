namespace UDF {
    export interface IUdfRequest<T> {
        Entity: IUdfEntity<T>
    }

    export interface IUdfBatchRequest {
        Batch: {
            Entities: IUdfEntity<any>[]
        }
    }

    export interface IUdfEntity<T> {
        id?: string,
        R?: number[],
        E: string,
        W: T
    }

    export interface IUdfAdcRequestData {
        ProductID: string,
        Tickers: string[],
        Formulas: string[]
    }

    export interface IUdfAdcResponseData {
        r: {
            v: string[]
        }[]
    }
}