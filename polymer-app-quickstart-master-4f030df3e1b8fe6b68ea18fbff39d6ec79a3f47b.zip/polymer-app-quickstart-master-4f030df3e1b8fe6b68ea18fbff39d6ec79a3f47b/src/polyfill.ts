// Polyfill for browser that doesn't support Web Component
// https://gist.github.com/ebidel/1d5ede1e35b6f426a2a7#file-wcr_lazyload-html-L20-L27
(function() {
    let onWCLoad = function() {
        // For native Imports, manually fire WCR so user code
        // can use the same code path for native and polyfill'd imports.
        if (!window["HTMLImports"]) {
            document.dispatchEvent(
                new CustomEvent("WebComponentsReady", {bubbles: true}));
        }
    };

    if ("registerElement" in document
        && "import" in document.createElement("link")
        && "content" in document.createElement("template")) {
        onWCLoad();
        // platform is good!
    } else {
        // polyfill the platform!
        var script = document.createElement("script");
        script.async = true;
        script.src = "polyfills/webcomponents-lite.min.js";
        script.onload  = onWCLoad;
        document.head.appendChild(script);
    }
})();
