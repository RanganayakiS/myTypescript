const applicationName = "PolymerQS";
const udfServiceUrl = "/Apps/UDF/MSF";

const Globals = {
    ApplicationName: applicationName,
    UdfServiceUrl: udfServiceUrl
};

export { Globals };