export interface ICompanyData {
    date: Date
    name: string
    value: number
    description: string
}