export interface ICompanyDataDto {
    date: string
    name: string
    value: number
    description: string
}