import {Container, interfaces} from "inversify";
import { Identifiers } from "../constants/Identifiers";
import { IDataService } from "../services/interfaces/dataService/IDataService";
import StaticDataService from "../services/entities/staticDataService/StaticDataService";
import {IDynamicDataService} from "../services/interfaces/dynamicDataService/IDynamicDataService";
import DynamicDataService from "../services/entities/dynamicDataService/DynamicDataService";
import RemoteDataService from "../services/entities/remoteDataService/RemoteDataService";
import {IJetService} from "../services/interfaces/jet/jetService/IJetService";
import JetService from "../services/entities/jet/jetService/JetService";
import AppBootstrapper from "../AppBootstrapper";
import {ICompanyData} from "../../common/model/ICompanyData";
import {IJetDataService} from "../services/interfaces/jetDataService/IJetDataService";
import JetDataService from "../services/entities/jetDataService/JetDataService";
import {IJetQuoteService} from "../services/interfaces/jet/jetQuoteService/IJetQuoteService";
import JetQuoteService from "../services/entities/jet/jetQuoteService/JetQuoteService";
import {IJetQuoteSubscription} from "../services/interfaces/jet/jetQuoteService/IJetQuoteSubscription";
import JetQuoteSubscription from "../services/entities/jet/jetQuoteService/JetQuoteSubscription";
import {IJetData} from "../services/entities/jetDataService/IJetData";
import {IJetSettingsService} from "../services/interfaces/jet/jetSettingsService/IJetSettingsService";
import JetSettingsService from "../services/entities/jet/jetSettingsService/JetSettingsService";
import {IAdcService} from "../services/interfaces/adcService/IAdcService";
import AdcService from "../services/entities/adcService/AdcService";
import JetArchiveService from "../services/entities/jet/jetArchiveService/JetArchiveService";
import {IJetArchiveService} from "../services/interfaces/jet/jetArchiveService/IJetArchiveService";


const container = new Container({ defaultScope: "Singleton" });
container.bind<IAppBootstrapper>(Identifiers.AppBootstrapper).to(AppBootstrapper);

// Services to wrap-up JET
container.bind<IJetService>(Identifiers.JetService).to(JetService);
container.bind<IJetSettingsService>(Identifiers.JetSettingsService).to(JetSettingsService);
container.bind<IJetArchiveService>(Identifiers.JetArchiveService).to(JetArchiveService);
// The sole purpose of Jet Quote Service is to create subscriptions via factory.
// It can be simplified by just using JetQuoteSubscription directly, yet these structure left for reference
container.bind<IJetQuoteService>(Identifiers.JetQuoteService).to(JetQuoteService);
container.bind<IJetQuoteSubscription>(Identifiers.JetQuoteSubscription).to(JetQuoteSubscription).inTransientScope();
container.bind<interfaces.Factory<IJetQuoteSubscription>>(Identifiers.JetQuoteSubscriptionFactory)
    .toFactory<IJetQuoteSubscription>((context: interfaces.Context) => {
        return () => {
            return context.container.get<IJetQuoteSubscription>(Identifiers.JetQuoteSubscription);
        }
    });

// These data services are bound to singleton scope:
container.bind<IAdcService>(Identifiers.AdcService).to(AdcService);
container.bind<IDataService<ICompanyData[]>>(Identifiers.StaticDataService).to(StaticDataService);
container.bind<IDataService<ICompanyData[]>>(Identifiers.RemoteDataService).to(RemoteDataService);
container.bind<IDynamicDataService<ICompanyData[]>>(Identifiers.DynamicDataService).to(DynamicDataService);
// These data services are bound to transient scope:
// Every Jet Panel has its own unique Jet Data Service, which in turn has its own unique Jet Quote Subscription
container.bind<IJetDataService<IJetData>>(Identifiers.JetDataService).to(JetDataService).inTransientScope();

export { container };