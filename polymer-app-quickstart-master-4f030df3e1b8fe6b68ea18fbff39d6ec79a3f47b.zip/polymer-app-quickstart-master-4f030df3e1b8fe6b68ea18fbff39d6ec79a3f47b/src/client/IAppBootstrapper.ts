interface IAppBootstrapper {
    run(): void
}