const Identifiers = {
    AppBootstrapper: Symbol("AppBootstrapper"),
    JetService: Symbol("JetService"),
    JetQuoteService: Symbol("JetQuoteService"),
    JetArchiveService: Symbol("JetArchiveService"),    
    JetSettingsService: Symbol("JetSettingsService"),
    JetQuoteSubscription: Symbol("JetQuoteSubscription"),
    JetQuoteSubscriptionFactory: Symbol("JetQuoteSubscriptionFactory"),
    AdcService: Symbol("JetQuoteService"),
    StaticDataService: Symbol("StaticDataService"),
    DynamicDataService: Symbol("DynamicDataService"),
    RemoteDataService: Symbol("RemoteDataService"),
    JetDataService: Symbol("JetDataService")
};

export { Identifiers };