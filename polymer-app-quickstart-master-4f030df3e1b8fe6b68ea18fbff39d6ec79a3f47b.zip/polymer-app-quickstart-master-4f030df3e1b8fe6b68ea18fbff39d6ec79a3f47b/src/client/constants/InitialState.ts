const InitialState = {
    mainJetPanel: {
        rics: ["RUB=", "EUR=", "CHF="],
        fields: [
            { id:"ric", type: "ALPHANUMERIC", label: "RIC"},
            { id:"DSPLY_NAME", type: "ALPHANUMERIC", label: "Display name", width: 160},
            { id:"CF_BID", type: "PRICE", label: "Bid" },
            { id:"CF_ASK", type: "PRICE", label: "Ask" },
            { id:"VALUE_TS1", type: "TIME", label: "Time" },
        ]
    },
    oilJetPanel: {
        rics: ["LCOc1", "CLc1", "1OQc1", "WTCLc1-LCOc1", "LGOc1"],
        fields: [
            {"id":"DSPLY_NAME","type":"ALPHANUMERIC","label":"Display name", "width":150},
            {"id":"CF_BID","type":"PRICE","label":"Bid"},
            {"id":"CF_ASK","type":"PRICE","label":"Ask"},
            {"id":"CF_LAST","label":"Last","type":"PRICE"},
            {"id":"CF_NETCHNG","label":"Net Chng","type":"PRICE"},
            {"id":"CF_CLOSE","label":"Close","type":"PRICE"},
            {"id":"CF_CURR","label":"Currency","type":"ENUMERATED"}
        ]
    },
    rusJetPanel: {
        rics: [".MCX", ".IRTS", "RUCBIR=ECI", "RU2YT=RR", "RU5YT=RR", "RU10YT=RR", "RU011428878="],
        fields: [
            {"id":"ric","type":"ALPHANUMERIC","label":"RIC"},
            {"id":"DSPLY_NAME","type":"ALPHANUMERIC","label":"Display name","width":200},
            {"id":"CF_LAST","label":"Last","type":"PRICE"},
            {"id":"PCTCHNG","label":"Pct.Chng","type":"PERCENT"}, //modified
            {"id":"CF_NETCHNG","label":"Net Chng","type":"PRICE"}
        ]
    },
    adcView: {
        rics: ["RU26207=", "RU26208=", "RU090694600=", "RU000A0JVTM6=", "RU000A0JVFN3=", "RU000A0JVNC0="],
        fields: [{
            "adcField": "Tr.FiCouponRate",
            "label": "Coupon Rate",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }, {
            "adcField": "Tr.FiMaturityDate",
            "label": "Maturity Date",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }, {
            "adcField": "TR.FIIssuerName",
            "label": "Issuer Name",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }, {
            "adcField": "TR.FICouponFrequency",
            "label": "Coupon Frequency",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }, {
            "adcField": "TR.FiCouponTypeDescription",
            "label": "Coupon Type Description",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }, {
            "adcField": "TR.FIPrincipalCurrency",
            "label": "Principal Currency",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }, {
            "adcField": "TR.ISINCode",
            "label": "ISIN Code",
            "showAll": false,
            "subFields": [],
            "subFieldsCount": 0
        }]
    }
};

export { InitialState };