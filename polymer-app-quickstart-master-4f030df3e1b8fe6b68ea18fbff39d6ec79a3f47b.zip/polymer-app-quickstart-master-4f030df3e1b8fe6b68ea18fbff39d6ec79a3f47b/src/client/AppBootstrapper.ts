import {inject, injectable} from "inversify";
import {IJetService} from "./services/interfaces/jet/jetService/IJetService";
import {IJetSettingsService} from "./services/interfaces/jet/jetSettingsService/IJetSettingsService";

import {Identifiers} from "./constants/Identifiers";

@injectable()
export default class AppBootstrapper implements IAppBootstrapper {
    @inject(Identifiers.JetService)
    private jetService: IJetService;

    @inject(Identifiers.JetSettingsService)
    private jetSettingsService: IJetSettingsService;

    public run() {
        document.addEventListener("WebComponentsReady", () => {
            this.jetService.init("PolymerAppQS", "Polymer App Quickstart");
            this.jetSettingsService.read("Configuration", "RDE_USER_CURRENT_THEME")
                .then((value) => {
                    document.body.setAttribute("theme", value.toLowerCase());
                })
                .catch((e) => {
                    console.log("Unable to retrieve theme from JET settings, using default theme")
                    document.body.setAttribute("theme", "pearl");
                });
            this.jetSettingsService.read("Configuration", "RDE_USER_CURRENT_TICK_COLOR")
                .then((value) => {
                    document.body.setAttribute("tickcolor", value.toLowerCase());
                })
                .catch((e) => {
                    console.log("Unable to retrieve tick color from JET settings")
                });
            });
    }
}