import * as Promise from "bluebird";

export default class HttpHelper {
    public static post<T>(url: string, body: any, headers: {[header: string]: string} = {}): Promise<T> {
        return HttpHelper.request("post", url, JSON.stringify(body), headers)
            .then((result: string) => {
                return <T> JSON.parse(result);
            });
    }

    public static request(type: string, url: string, body: string, headers: {[header: string]: string} = {}): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.open(type, url);

            Object.keys(headers).forEach((header: string) => {
                xhr.setRequestHeader(header, headers[header]);
            });

            xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(xhr.response);
                } else {
                    reject({
                        status: xhr.status,
                        statusText: xhr.statusText
                    });
                }
            };
            xhr.onerror = () => {
                reject({
                    status: xhr.status,
                    statusText: xhr.statusText
                });
            };
            
            xhr.send(body);
        });
    }
}