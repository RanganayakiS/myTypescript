import IJetApi = JET.IJetApi;
import IJet2Api = JET.IJet2Api;
export class JetHelper {
    public static getJet() : IJetApi {
        return <IJetApi>window["JET"];
    }
    public static getJet2() : IJet2Api {
        const jetApp = document.querySelector("JET-APP");
        return <IJet2Api><any>jetApp;
    }
}