import {container} from "../../config/inversify.config";
import {Identifiers} from "../../constants/Identifiers";

import {IDataService} from "../../services/interfaces/dataService/IDataService";
import {IDynamicDataService} from "../../services/interfaces/dynamicDataService/IDynamicDataService";

import {IDataPanelComponent} from "../data-panel/IDataPanelComponent";
import {ICompanyData} from "../../../common/model/ICompanyData";
import {IJetPanelComponent} from "../jet-panel/IJetPanelComponent";
import {IDataBarsComponent} from "../data-bars/IDataBarsComponent";
import {InitialState} from "../../constants/InitialState";
import {IJetArchiveService} from "../../services/interfaces/jet/jetArchiveService/IJetArchiveService";
import {IJetPanelArchiveData} from "../jet-panel/IJetPanelArchiveData";

const JetArchiveKey = "CUSTOM_JET_PANEL_VIEW";

@component("main-view")
class MainView extends polymer.Base
{
    private jetArchive: IJetArchiveService;
    private dataService: IDataService<ICompanyData[]>;
    private dynamicDataService: IDynamicDataService<ICompanyData[]>;
    private remoteDataService: IDataService<ICompanyData[]>;

    private dynamicDataServiceRefreshHandler: EventListener;
    private jetPanelEditHandler: EventListener;

    private dataPanels: IDataPanelComponent[];
    private dataBars: IDataBarsComponent[];
    private jetPanels: IJetPanelComponent[];


    public ready() {
        // Injection via decorators is, unfortunately, impossible into Polymer components
        // as ready() is used instead of class constructor for the components
        this.dataService = container.get<IDataService<ICompanyData[]>>(Identifiers.StaticDataService);
        this.dynamicDataService = container.get<IDynamicDataService<ICompanyData[]>>(Identifiers.DynamicDataService);
        this.remoteDataService = container.get<IDynamicDataService<ICompanyData[]>>(Identifiers.RemoteDataService);
        this.jetArchive  = container.get<IJetArchiveService>(Identifiers.JetArchiveService);

        // Also in case on Polymer elements event handlers should be initialized in ready() method, otherwise they are undefined
        this.dynamicDataServiceRefreshHandler = (e: Event) => {
            this.setPanelData(this.remoteDataService, remoteDataPanel, remoteDataBars);
            remoteDataBars.data = remoteDataPanel.data;
        };
        this.jetPanelEditHandler = (e) => {
            let data = <IJetPanelArchiveData> e["detail"];
            this.jetArchive.put(JetArchiveKey, data);
        };

        let staticPanel = <IDataPanelComponent> this.$.staticPanel;
        let dynamicPanel = <IDataPanelComponent> this.$.dynamicPanel;
        let remoteDataPanel = <IDataPanelComponent> this.$.remoteDataPanel;
        let staticDataBars = <IDataBarsComponent> this.$.staticDataBars;
        let dynamicDataBars = <IDataBarsComponent> this.$.dynamicDataBars;
        let remoteDataBars = <IDataBarsComponent> this.$.remoteDataBars;

        this.dataPanels = [];
        this.dataPanels.push(staticPanel);
        this.dataPanels.push(dynamicPanel);
        this.dataPanels.push(remoteDataPanel);

        this.dataBars = [];
        this.dataBars.push(staticDataBars);
        this.dataBars.push(dynamicDataBars);
        this.dataBars.push(remoteDataBars);


        this.setPanelData(this.dataService, staticPanel, staticDataBars);

        this.dynamicDataService.onDataUpdate().subscribe((service, data) => this.onDynamicDataServiceUpdate(service, data));
        this.dynamicDataService.start();
        this.setPanelData(this.dynamicDataService, dynamicPanel, dynamicDataBars);



        remoteDataPanel.addEventListener("onPanelRefreshClicked", this.dynamicDataServiceRefreshHandler);
        remoteDataBars.addEventListener("onPanelRefreshClicked", this.dynamicDataServiceRefreshHandler);

        this.setPanelData(this.remoteDataService, remoteDataPanel, remoteDataBars);
        remoteDataBars.data = remoteDataPanel.data;


        let mainJetPanel = <IJetPanelComponent> this.$.mainJetPanel;
        let oilJetPanel = <IJetPanelComponent> this.$.oilJetPanel;
        let rusJetPanel = <IJetPanelComponent> this.$.rusJetPanel;

        this.jetPanels = [];
        this.jetPanels.push(mainJetPanel);
        this.jetPanels.push(oilJetPanel);
        this.jetPanels.push(rusJetPanel);

        mainJetPanel.addEventListener("onJetPanelEdit", this.jetPanelEditHandler);

        this.jetArchive.get<IJetPanelArchiveData>(JetArchiveKey)
            .catch(() => {
                mainJetPanel.init(InitialState.mainJetPanel.rics, InitialState.mainJetPanel.fields);
            })
            .then((data) => {
                if (data) {
                    mainJetPanel.init(data.rics, data.fields);
                } else {
                    mainJetPanel.init(InitialState.mainJetPanel.rics, InitialState.mainJetPanel.fields);
                }
            });

        oilJetPanel.init(InitialState.oilJetPanel.rics, InitialState.oilJetPanel.fields);
        rusJetPanel.init(InitialState.rusJetPanel.rics, InitialState.rusJetPanel.fields);

    }

    public detached() {
        console.log("Main view detached");
        this.jetPanels[0].removeEventListener("onJetPanelEdit", this.jetPanelEditHandler);
        this.dataPanels[1].removeEventListener("onPanelRefreshClicked", this.dynamicDataServiceRefreshHandler);
        this.dataBars[1].removeEventListener("onPanelRefreshClicked", this.dynamicDataServiceRefreshHandler);
        this.dynamicDataService.stop();
    }

    private setPanelData(service: IDataService<ICompanyData[]>, panel: IDataPanelComponent, bars?: IDataBarsComponent) {
        service.getData()
            .then((data: ICompanyData[]) => {
                panel.data = data;
                if (bars) {
                    bars.data = data;
                }
            });
    }

    private onDynamicDataServiceUpdate(service: IDynamicDataService<ICompanyData[]>, data: ICompanyData[]): void {
        this.dataPanels[1].data = data.slice();
        this.dataBars[1].data = this.dataPanels[1].data;
    }
}

MainView.register();