import {container} from "../../config/inversify.config";
import {Identifiers} from "../../constants/Identifiers";
import {IAdcService} from "../../services/interfaces/adcService/IAdcService";
import {IAdcServiceResponse} from "../../services/interfaces/adcService/IAdcServiceResponse";
import EmeraldAutosuggest = ELF.EmeraldAutosuggest;
import IAutosuggestResultRic = ELF.IAutosuggestResultRic;
import IAutosuggestResultField = ELF.IAutosuggestResultField;
import IEmeraldAutosuggestEvent = ELF.IEmeraldAutosuggestEvent;
import EmeraldPopupMenu = ELF.EmeraldPopupMenu;
import EmeraldAutosuggestEventHandler = ELF.EmeraldAutosuggestEventHandler;
import {IJetArchiveService} from "../../services/interfaces/jet/jetArchiveService/IJetArchiveService";
import {InitialState} from "../../constants/InitialState";

const JetArchiveKey = "ADC_VIEW";

const FieldPrefix = "f";

type RicData = {
    [field: string]: {
        [subfield: string]: string
    }[]
}

interface IAdcArchive {
    rics: string[];
    fields: IAdcTableField[];
}

interface ITableDataItem {
    ric: string;
    fields: RicData;
}

interface IAdcTableField {
    id?: string;
    adcField: string;
    label?: string;
    showAll?: boolean;
    subFields: string[],
    subFieldsCount: number;
}

interface IPopupValue {
    field?: IAdcTableField,
    ric?: string,
    action: "f_remove" | "f_subfields" | "r_remove"
}

@component("adc-view") class AdcView extends polymer.Base
{
    private adcService: IAdcService;
    private jetArchive: IJetArchiveService;

    private ricAutoSuggestInput: HTMLInputElement;
    private ricAutoSuggest: EmeraldAutosuggest<IAutosuggestResultRic>;
    private fieldAutoSuggestInput: HTMLInputElement;
    private fieldAutoSuggest: EmeraldAutosuggest<IAutosuggestResultField>;
    private ricAutosuggestEventHandler: EmeraldAutosuggestEventHandler<IAutosuggestResultRic>;
    private fieldAutosuggestEventHandler: EmeraldAutosuggestEventHandler<IAutosuggestResultField>;

    private popupMenu: EmeraldPopupMenu;

    public popupItemSelectedListener: EventListener;


    @property({type: Array})
    private tableData: ITableDataItem[];

    @property({type: Array})
    private fields: IAdcTableField[];

    public ready() {
        this.adcService  = container.get<IAdcService>(Identifiers.AdcService);
        this.jetArchive  = container.get<IJetArchiveService>(Identifiers.JetArchiveService);

        this.fields = [];
        this.tableData = [];

        this.jetArchive.get<IAdcArchive>(JetArchiveKey)
            .catch(() => this.init(InitialState.adcView.rics, InitialState.adcView.fields))
            .then((data) => {
                if (data) {
                    this.init(data.rics, data.fields);
                } else {
                    this.init(InitialState.adcView.rics, InitialState.adcView.fields);
                }
            });

        this.popupMenu = this.$.popupMenu;
        this.popupItemSelectedListener = (e) => this.popupItemSelected(e);
        this.popupMenu.addEventListener("item-select", this.popupItemSelectedListener);
        this.initAutosuggest();
    }

    public detached() {
        this.ricAutoSuggest.addEventListener("item-select", this.ricAutosuggestEventHandler);
        this.fieldAutoSuggest.removeEventListener("item-select", this.fieldAutosuggestEventHandler);
        this.popupMenu.removeEventListener("item-select", this.popupItemSelectedListener);
    }


    private init(rics: string[], fields: IAdcTableField[]) {
        this.addRics(rics);
        this.addFields(fields);
    }

    private addRics(rics: string[]) {
        let addedRics = this.tableData.map(d => { return d.ric });
        let added = false;
        rics.forEach((ric) => {
            if (addedRics.indexOf(ric) == -1) {
                added = true;
                this.push("tableData", {
                    ric,
                    fields: {}
                });
            }
        });
        if (added) {
            this.saveArchive();
            this.requestAdcData(rics, this.fields.map(f =>  f.adcField));
        }
    }

    private addFields(fields: IAdcTableField[]) {
        let addedFields = this.fields.map(f => { return f.adcField });
        let added = false;
        fields.forEach(field => {
            if (addedFields.indexOf(field.adcField) == -1) {
                added = true;
                field.id = FieldPrefix + this.fields.length;
                this.push("fields", field);
            }
        });
        if (added) {
            this.saveArchive();
            this.requestAdcData(this.tableData.map(d => { return d.ric; }), fields.map(f =>  f.adcField));
        }
    }

    private saveArchive() {
        let archiveData: IAdcArchive = {
            rics: this.tableData.map(td => td.ric),
            fields: this.fields.map(f => {
                return {
                    adcField: f.adcField,
                    label: f.label,
                    showAll: f.showAll,
                    subFields: [],
                    subFieldsCount: 0
                }
            })
        };
        this.jetArchive.put(JetArchiveKey, archiveData);
    }

    private removeField(field: IAdcTableField) {
        let fid = this.fields.indexOf(field);
        if (fid > -1) {
            this.splice("fields", fid, 1);
            this.saveArchive();
        }
    }

    private removeRic(ric: string) {
        let tableDataItem = this.tableData.filter(f => { return f.ric == ric});
        if (tableDataItem) {
            let fid = this.tableData.indexOf(tableDataItem[0]);
            this.splice("tableData", fid, 1);
            this.saveArchive();
        }
    }

    private getField(item: ITableDataItem, field: string, subField: string = "_default"): string {
        if (item.fields[field] && item.fields[field][0][subField]) {
            return item.fields[field][0][subField];
        }
        return "";
    }

    private getHeaderRowSpan(showAll: boolean, count: number) {
        if (showAll && count > 0) {
            return 1;
        }
        return 2;
    }

    private getHeaderColSpan(showAll: boolean, count: number) {
        if (!showAll || count < 1) {
            return 1;
        }
        return count;
    }

    private popupItemSelected(e) {
        let value: IPopupValue = (<any> e).detail.item.value;
        switch (value.action) {
            case "f_remove":
                this.removeField(value.field);
                break;
            case "f_subfields":
                this.switchSubfields(value.field);
                break;
            case "r_remove":
                this.removeRic(value.ric);
                break;
        }
    };

    private switchSubfields(field: IAdcTableField) {
        let fid = this.fields.indexOf(field);
        if (fid > -1) {
            this.set(["fields", fid, "showAll"], !field.showAll);
            this.saveArchive();
        }
    }

    private showFieldMenu(e) {
        e.preventDefault();
        let field = <IAdcTableField> e.model.field;
        this.popupMenu.data = [
            { label: "Remove field", value: { field: field, action: "f_remove" } },
            { label: field.showAll ? "Hide subfields" : "Show subfields", value: { field: field, action: "f_subfields" } },
        ];
        this.popupMenu.target = { x: e.pageX, y: e.pageY };
        this.popupMenu.show();
    }

    private showRicMenu(e) {
        e.preventDefault();
        let item = <ITableDataItem> e.model.item;
        this.popupMenu.data = [
            { label: "Remove RIC", value: { ric: item.ric, action: "r_remove" } },
        ];
        this.popupMenu.target = { x: e.pageX, y: e.pageY };
        this.popupMenu.show();
    }

    private debug() {
        console.log(this.fields);
        console.log(this.tableData);
    }


    private initAutosuggest(): void {
        this.ricAutosuggestEventHandler = (e) => this.autosuggestRicItemSelect(e);
        this.fieldAutosuggestEventHandler = (e) => this.autosuggestFieldItemSelect(e);

        this.ricAutoSuggestInput = <HTMLInputElement> this.$.ricInput;
        this.ricAutoSuggest = <EmeraldAutosuggest<IAutosuggestResultRic>> this.$.ricAutoSuggest;
        this.ricAutoSuggest.setInput(this.ricAutoSuggestInput);
        this.ricAutoSuggest.addEventListener("item-select", this.ricAutosuggestEventHandler);
        this.fieldAutoSuggestInput = <HTMLInputElement> this.$.fieldInput;
        this.fieldAutoSuggest = <EmeraldAutosuggest<IAutosuggestResultField>> this.$.fieldAutoSuggest;
        this.fieldAutoSuggest.setInput(this.fieldAutoSuggestInput);
        this.fieldAutoSuggest.setTransformer((data) => {
            data.suggestions = data.suggestions.reduce((acc, el) => {
                if (el.value.p.fsrc.toUpperCase() == "ADC") {
                    acc.push(el);
                }
                return acc;
            }, []);
            if (data.suggestions.length > 0) {
                data.suggestions[0].highlighted = true;
            }
            return data;
        });
        this.fieldAutoSuggest.addEventListener("item-select", this.fieldAutosuggestEventHandler);
        this.ricAutoSuggest.moreSearchDisabled = true;
        this.fieldAutoSuggest.moreSearchDisabled = true;
    }

    private autosuggestRicItemSelect(e: IEmeraldAutosuggestEvent<IAutosuggestResultRic>) {
        let ric = e.detail.item.value.p.RIC;
        if (ric) {
            this.addRics([ric]);
        }
        this.ricAutoSuggestInput.value = "";
    }
    private autosuggestFieldItemSelect(e: IEmeraldAutosuggestEvent<IAutosuggestResultField>) {
        let field: IAdcTableField = {
            adcField: e.detail.item.value.p.fn,
            label: e.detail.item.value.p.fl,
            showAll: true,
            subFields: [],
            subFieldsCount: 0
        };
        if (field.adcField) {
            this.addFields([field]);
        }
        this.fieldAutoSuggestInput.value = "";
    }

    private requestAdcData(rics: string[], fields: string[]) {
        if (rics.length == 0 || fields.length == 0) {
            return;
        }
        this.adcService.getData(rics, fields)
            .then(response => {
                this.mergeResponse(response);
            });
    }

    private mergeResponse(response: IAdcServiceResponse) {
         Object.keys(response).forEach(ric => {
            Object.keys(response[ric]).forEach(fieldId => {
                let fields = this.fields.filter(f => f.adcField == fieldId);
                let field: IAdcTableField;
                if (fields.length > 0) {
                    field = fields[0];
                } else {
                    field = {
                        id: FieldPrefix + this.fields.length,
                        adcField: fieldId,
                        label: fieldId,
                        showAll: true,
                        subFields: [],
                        subFieldsCount: 0
                    };
                    this.push("fields", field);
                }
                let fId = this.fields.indexOf(field);
                Object.keys(response[ric][fieldId][0]).forEach(subfield => {
                    if (subfield == "_default") {
                        return;
                    }
                    if (field.subFields.indexOf(subfield) == -1) {
                        this.push(["fields", fId, "subFields"].join("."), subfield);
                        this.set(["fields", fId, "subFieldsCount"], field.subFieldsCount + 1);
                    }
                });
            });
             let ricData = this.tableData.filter(f => f.ric == ric);
             if (ricData.length > 0) {
                 let id = this.tableData.indexOf(ricData[0]);
                 let changed = false;
                 Object.keys(response[ric]).forEach((field) => {
                     let fieldData = this.fields.filter(f => f.adcField == field)[0];
                     this.tableData[id].fields[fieldData.id] = response[ric][fieldData.adcField];
                     changed = true;
                 });
                 if (changed) {
                     let newFields = this.tableData[id];
                     // Dirty way to notify about the changes
                     this.set(["tableData", id], { ric: this.tableData[id].ric,  fields: {}});
                     this.set(["tableData", id], newFields);
                 }
             } else {
                 this.push("tableData", {
                     ric,
                     fields: response[ric]
                 });
             }
        })
    }
}

AdcView.register();