import {ICompanyData} from "../../../common/model/ICompanyData";
export interface IDataPanelComponent extends HTMLElement {
    header: string;
    data: ICompanyData[];
}