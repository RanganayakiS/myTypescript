import * as moment from "moment";
import * as numeral from "numeral";

import {ICompanyData} from "../../../common/model/ICompanyData";
import {IDataPanelComponent} from "./IDataPanelComponent";
import HTMLDomRepeatElement = Polymer.HTMLDomRepeatElement;

@component("data-panel")
class DataPanelComponent extends polymer.Base implements IDataPanelComponent
{
    @property({type: String, value: "Data"})
    public header: string;
    
    @property({type: Array})
    public data: ICompanyData[];

    @property({type: Boolean, value: false})
    public showRefresh: boolean;

    private domRepeatElement: HTMLDomRepeatElement;

    public ready() {
        console.debug(this.header + " ready");
        this.domRepeatElement = <HTMLDomRepeatElement> document.getElementById("staticPanel");
    }

    public detached() {
        console.debug(this.header + " detached");
    }

    public refresh() {
        this.dispatchEvent(new CustomEvent("onPanelRefreshClicked"));
    }

    private parseDate(date: Date): string {
        return moment(date).format("YYYY-MM-DD");
    }
    private parseValue(value: number): string {
        return numeral(value).format("0,0");
    }

    @observe("data")
    private onDataChange(newValue: ICompanyData[], oldValue: ICompanyData[]) {
        //console.debug(this.header + " data changed");
    }
}

DataPanelComponent.register();