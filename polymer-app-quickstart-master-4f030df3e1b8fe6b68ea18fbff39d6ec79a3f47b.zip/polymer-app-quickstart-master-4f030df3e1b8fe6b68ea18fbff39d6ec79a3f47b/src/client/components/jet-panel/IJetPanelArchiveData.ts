import {IRealtimeField} from "./IRealtimeField";
export interface IJetPanelArchiveData {
    rics: string[];
    fields: IRealtimeField[];
}