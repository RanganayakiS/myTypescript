export interface IRealtimeField {
    id: string,
    label: string,
    type: string
    width?: number;
}
