import * as moment from "moment";
import * as numeral from "numeral";

import {container} from "../../config/inversify.config";
import {IJetPanelComponent} from "./IJetPanelComponent";
import {IJetData} from "../../services/entities/jetDataService/IJetData";
import {Identifiers} from "../../constants/Identifiers";
import EmeraldAutosuggest = ELF.EmeraldAutosuggest;
import IEmeraldAutosuggestEvent = ELF.IEmeraldAutosuggestEvent;
import IAutosuggestResultRic = ELF.IAutosuggestResultRic;
import IAutosuggestResultField = ELF.IAutosuggestResultField;
import {IJetDataService} from "../../services/interfaces/jetDataService/IJetDataService";
import {IRealtimeField} from "./IRealtimeField";
import EmeraldAutosuggestEventHandler = ELF.EmeraldAutosuggestEventHandler;
import {EventDispatcher, IEvent} from "strongly-typed-events";
import {IJetPanelArchiveData} from "./IJetPanelArchiveData";


interface IJetTableElement {
    value: string | number,
    oldValue?: string | number
}

declare type JetTableData = { [id: string]: IJetTableElement };

@component("jet-panel")
class JetPanelComponent extends polymer.Base implements IJetPanelComponent {
    private jetDataService: IJetDataService<IJetData>;

    private ricAutoSuggestInput: HTMLInputElement;
    private ricAutoSuggest: EmeraldAutosuggest<IAutosuggestResultRic>;
    private fieldAutoSuggestInput: HTMLInputElement;
    private fieldAutoSuggest: EmeraldAutosuggest<IAutosuggestResultField>;
    private ricAutosuggestEventHandler: EmeraldAutosuggestEventHandler<IAutosuggestResultRic>;
    private fieldAutosuggestEventHandler: EmeraldAutosuggestEventHandler<IAutosuggestResultField>;

    @property({type: String, value: "Data"})
    public header: string;

    @property({type: Array})
    public data: JetTableData[];

    @property({type: Array})
    public rics: string[];

    @property({type: Array})
    public fields: IRealtimeField[];

    @property({type: Boolean})
    public allowEdit: boolean;
    
    public ready() {
        this.data = [];
        this.jetDataService = container.get<IJetDataService<IJetData>>(Identifiers.JetDataService);
        this.jetDataService.onDataUpdate().subscribe((service: IJetDataService<IJetData>, data: IJetData) => this.onDataUpdate(service, data));
        if (this.allowEdit) {
            this.async(this.initAutosuggest);
        }
        console.debug(this.header + " ready");
    }

    public init(rics: string[], fields: IRealtimeField[]) {
        this.rics = [...rics];
        this.fields = [...fields];
        this.rics.forEach((ric) => { this.jetDataService.addRic(ric)});
        this.fields.filter((field) => { return field.id != "ric"; })
            .forEach((field) => { this.jetDataService.addField(field.id)});
    }

    public detached() {
        this.jetDataService.dispose();
        this.jetDataService = null;
        this.ricAutoSuggest.addEventListener("item-select", this.ricAutosuggestEventHandler);
        this.fieldAutoSuggest.removeEventListener("item-select", this.fieldAutosuggestEventHandler);
        console.debug(this.header + " detached");
    }

    private getField(item: JetTableData, field: IRealtimeField):string {
        if (item[field.id] && item[field.id].value != null) {
            if (field.type == "DATE") {
                return moment.unix(<number> item[field.id].value).format("YYYY-MM-DD");
            } else if (field.type == "TIME") {
                return moment(<number> item[field.id].value * 1000).format("HH:mm:ss")
            } else if (field.type == "PERCENT") {
                return item[field.id].value.toString() + "%";
            }
            return item[field.id].value.toString();
        }
        return "";
    }

    // http://emea1.apps.cp.thomsonreuters.com/apps/elementlibrary#/Documentation?doc=sections%2Ffeatures_tickcolor.html
    private getChange(item: JetTableData, field: IRealtimeField): string {
        if (item[field.id]) {
            let value = item[field.id].value;
            let oldValue = item[field.id].oldValue;
            if ((field.type == "PRICE" || field.type == "PERCENT") && oldValue) {
                if (value > oldValue) {
                    return "upchange";
                } else if (value < oldValue) {
                    return "downchange";
                }
                return "neutral"
            }
        }

        return ""
    }

    private getWidth(field: IRealtimeField): string {
        return field.width ? field.width + "px" : "50px";
    }

    private isNumber( field: IRealtimeField): boolean {
        return  field.type.toUpperCase() == "PRICE" ||
                field.type.toUpperCase() == "PERCENT" ||
                field.type.toUpperCase() == "INTEGER" ||
                field.type.toUpperCase() == "DATE" ||
                field.type.toUpperCase() == "TIME";
    }

    private onHeaderDoubleClick(e: any): void {
        if (this.allowEdit) {
            let field = <IRealtimeField> e.model.field;
            let id = e.model.index;
            this.splice("fields", id, 1);
            if (field.id != "ric" && this.fields.filter((f) => { return f.id == field.id}).length == 0) {
                this.jetDataService.removeField(field.id);
            }
        }
    }

    private onElementDoubleClick(e: any): void {
        if (this.allowEdit) {
            let field = <IRealtimeField> e.model.field;
            if (e.model.index == 0) {
                // Getting properties of parent template is a little tricky:
                // https://github.com/Polymer/polymer/issues/1919
                let data = <JetTableData> e.model.dataHost.dataHost.item;
                let ric = <string> data["ric"].value;
                let id = e.model.dataHost["ricId"];
                
                this.splice("rics", id, 1);
                this.splice("data", id, 1);

                if (this.rics.indexOf(ric) == -1) {
                    this.jetDataService.removeRic(ric);
                }
            }

        }

    }

    private onDataUpdate(service: IJetDataService<IJetData>, data: IJetData) {
        let dataByRic = this.data.reduce((acc: { [id: string]: JetTableData }, el) => { 
            let ric =  el["ric"];
            if (ric) {
                acc[ric.value.toString()] = el; 
               
            }
            return acc;
        }, {});
        this.data = this.rics.map((ric) => {
            let fieldData = Object.keys(data[ric]).reduce((acc, field) => {
                let pair: IJetTableElement = {
                    value: data[ric][field]
                };
                if (dataByRic[ric] && dataByRic[ric][field]) {
                    pair.oldValue = dataByRic[ric][field].value;
                }
                acc[field] = pair;
                return acc;
            }, {})
            return {
                ric: { value: ric },
                ...fieldData
            }
        });
    }

    private initAutosuggest(): void {
        this.ricAutosuggestEventHandler = (e) => this.autosuggestRicItemSelect(e);
        this.fieldAutosuggestEventHandler = (e) => this.autosuggestFieldItemSelect(e);

        this.ricAutoSuggestInput = <HTMLInputElement> this.$$("#ricInput");
        this.ricAutoSuggest = <EmeraldAutosuggest<IAutosuggestResultRic>> this.$$("#ricAutoSuggest");
        this.ricAutoSuggest.setInput(this.ricAutoSuggestInput);
        this.ricAutoSuggest.addEventListener("item-select", this.ricAutosuggestEventHandler);
        this.fieldAutoSuggestInput = <HTMLInputElement> this.$$("#fieldInput");
        this.fieldAutoSuggest = <EmeraldAutosuggest<IAutosuggestResultField>> this.$$("#fieldAutoSuggest");
        this.fieldAutoSuggest.setInput(this.fieldAutoSuggestInput);
        this.fieldAutoSuggest.setTransformer((data) => {
            data.suggestions = data.suggestions.reduce((acc, el) => {
                if (el.value.p.firt == true && el.value.p.fimo == false) {
                    acc.push(el);
                }
                return acc;
            }, []);
            if (data.suggestions.length > 0) {
                data.suggestions[0].highlighted = true;
            }
           return data;
        });
        this.fieldAutoSuggest.addEventListener("item-select", this.fieldAutosuggestEventHandler);

        this.ricAutoSuggest.moreSearchDisabled = true;
        this.fieldAutoSuggest.moreSearchDisabled = true;
    }

    private autosuggestRicItemSelect(e: IEmeraldAutosuggestEvent<IAutosuggestResultRic>) {
        let ric = e.detail.item.value.p.RIC;
        if (ric) {
            this.push("rics", ric);
            this.jetDataService.addRic(ric);
            this.fire("onJetPanelEdit", this.getPanelArchiveData());
        }
        this.ricAutoSuggestInput.value = "";
    }
    private autosuggestFieldItemSelect(e: IEmeraldAutosuggestEvent<IAutosuggestResultField>) {
        let field: IRealtimeField = {
            id: e.detail.item.value.p.fn,
            label: e.detail.item.value.p.fl,
            type: e.detail.item.value.p.fdt,
        };
        if (field.id) {
            this.push("fields", field);
            this.jetDataService.addField(field.id);
            this.fire("onJetPanelEdit", this.getPanelArchiveData());
        }
        this.fieldAutoSuggestInput.value = "";
    }

    private getPanelArchiveData(): IJetPanelArchiveData {
        return {
            rics: this.rics,
            fields: this.fields
        }
    }
}

JetPanelComponent.register();