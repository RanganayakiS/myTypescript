import {IRealtimeField} from "./IRealtimeField";
export interface IJetPanelComponent extends HTMLElement {
    init(rics: string[], fields: IRealtimeField[]);
}