export interface IArchiveViewComponent extends HTMLElement {
    refresh(): void;
}