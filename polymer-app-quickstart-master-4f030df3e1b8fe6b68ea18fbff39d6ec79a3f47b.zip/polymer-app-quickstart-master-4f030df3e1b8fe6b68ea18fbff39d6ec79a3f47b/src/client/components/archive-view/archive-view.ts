import * as Promise from "bluebird";
import {container} from "../../config/inversify.config";
import {Identifiers} from "../../constants/Identifiers";
import {IJetArchiveService} from "../../services/interfaces/jet/jetArchiveService/IJetArchiveService";
import {IArchiveViewComponent} from "./IArchiveViewComponent";
import CoralList = ELF.CoralList;
import ICoralListElement = ELF.ICoralListElement;
import AmberNotification = ELF.AmberNotification;
import CoralDialog = ELF.CoralDialog;
import ICoralDialogEventData = ELF.ICoralDialogEventData;


@component("archive-view")
class ArchiveView extends polymer.Base implements IArchiveViewComponent
{
    private jetArchive: IJetArchiveService;
    private notification: AmberNotification;
    private dialog: CoralDialog;

    private coralList: CoralList;
    private textarea: HTMLTextAreaElement;

    private onItemSelectHandler: EventListener;

    private itemSelected: boolean;
    private selectedItemKey: string;

    public ready(): void {
        this.jetArchive  = container.get<IJetArchiveService>(Identifiers.JetArchiveService);
        this.coralList = this.$.keyList;
        this.textarea = this.$.archiveValue;
        this.notification = this.$.notification;
        this.dialog = this.$.dialog;

        this.onItemSelectHandler = (e: any) => {
            let item = <ICoralListElement> e.detail.item;
            this.jetArchive.get(item.id).then((data) => {
                    this.textarea.value = JSON.stringify(data, null, 4)
                    this.itemSelected = true;
                    this.selectedItemKey = item.id;
                });
        };
        this.coralList.addEventListener("item-select", this.onItemSelectHandler);

        this.refresh()
    }

    public detached(): void {
        this.coralList.removeEventListener("item-select", this.onItemSelectHandler);
    }

    public refresh(): void {
        this.jetArchive.getAllKeys().then((keys) => {
            let data: ICoralListElement[] = keys.map(key => {
                return { id: key, label: key };
            });
            this.coralList.data = data;
        });
        this.textarea.value = "";
        this.selectedItemKey = null;
        this.itemSelected = false;
    }

    private removeAll() {
        this.showDialog("Remove all JET Archive keys", "Are you sure to remove all JET Archive keys?")
            .then(result => {
                if (result.action == "confirm") {
                    this.jetArchive.clear();
                    this.refresh();
                }
            });
    }

    private saveKey() {
        try {
            let data = JSON.parse(this.textarea.value);
            if (this.selectedItemKey) {
                this.notification.info(`Saved key to JET Archive: ${this.selectedItemKey}`);
                this.jetArchive.put(this.selectedItemKey, data);
            }
        } catch (e) {
            this.notification.warn("Unable to save to JET Archive, invalid JSON format");
        }
    }

    private showDialog(header: string, text: string): Promise<ICoralDialogEventData> {
        this.dialog.header = header;
        this.dialog.setContent(text);
        return new Promise<ICoralDialogEventData>((resolve, reject) => {
            let handler = (e) => {
                let detail = <ICoralDialogEventData> e.detail;
                if (detail.action != "show") {
                    this.dialog.removeEventListener("action", handler, false);
                    resolve(detail);
                }
            };
            this.dialog.addEventListener("action", handler, false);
            this.dialog.show();
        });
    }

}

ArchiveView.register();