import {container} from "../../config/inversify.config";
import {Identifiers} from "../../constants/Identifiers";
import EmeraldNavBar = ELF.EmeraldNavBar;
import IEmeraldNavBarElement = ELF.IEmeraldNavBarElement;
import {IJetArchiveService} from "../../services/interfaces/jet/jetArchiveService/IJetArchiveService";
import {IArchiveViewComponent} from "../archive-view/IArchiveViewComponent";

const JetArchiveKey = "ACTIVE_PAGE";

@component("app-view")
class AppView extends polymer.Base
{
    private jetArchive: IJetArchiveService;
    private archiveView: IArchiveViewComponent;

    private navigation: EmeraldNavBar;
    private navigationItemSelectHandler: (e: any) => void;

    public ready() {
        this.jetArchive  = container.get<IJetArchiveService>(Identifiers.JetArchiveService);
        this.navigation = <EmeraldNavBar> this.$.navigation;

        this.archiveView = this.$.archiveView;

        let navData: IEmeraldNavBarElement[] = [
            { id: "0", label: "Main View" },
            { id: "1", label: "ADC View" },
            { id: "2", label: "Archive View" }
        ];

        this.jetArchive.get<string>(JetArchiveKey)
            .catch(() => {
                this.init(navData, "0")
            })
            .then((pageId) => {
                if (!this.init(navData, pageId)) {
                    this.init(navData, "0");
                }
            });

        this.navigationItemSelectHandler = (e: any) => {
            let item = <IEmeraldNavBarElement> e.detail;
            this.$.appView.selected = item.id;
            this.jetArchive.put(JetArchiveKey, item.id);
            if (item.id == "2") {
                this.archiveView.refresh();
            }
        };
        this.navigation.addEventListener("item-select",  this.navigationItemSelectHandler);
    }

    public detached() {
        this.navigation.removeEventListener("item-select",  this.navigationItemSelectHandler);
    }

    private init(navData, pageId: string): boolean {
        let page = navData.filter(d => d.id == pageId);
        if (page) {
            let pageIndex = navData.indexOf(page[0]);
            navData[pageIndex].selected = true;
            this.$.appView.selected = pageId;
            this.navigation.data = navData;
            return true;
        }
        return false;
    }
}

AppView.register();