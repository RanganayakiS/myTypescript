import * as numeral from "numeral";

import {IDataBarsComponent} from "./IDataBarsComponent";
import {IDataBarsData} from "./IDataBarsData";

@component("data-bars")
class DataBarsComponent extends polymer.Base implements IDataBarsComponent
{
    @property({type: String, value: "Data"})
    public header: string;

    @property({type: Array})
    public data: IDataBarsData[];
    public preparedData: IDataBarsPreparedData[];


    @property({type: Boolean, value: false})
    public showRefresh: boolean;

    public ready() {
        console.debug(this.header + " ready");
    }

    public detached() {
        console.debug(this.header + " detached");
    }

    public refresh() {
        this.dispatchEvent(new CustomEvent("onPanelRefreshClicked"));
    }

    private parseValue(value: number): string {
        let space = "\xa0";
        return numeral(value).format("($" + space + "0.0" + space + "a)");
    }

    @observe("data")
    private onDataChange(data: IDataBarsData[], oldData: IDataBarsData[]) {
        //console.debug(this.header + " data changed");
        let max = Math.max(...data.map((item) => item.value));
        this.preparedData = data.map((item: IDataBarsData) => {
            let ratio = Math.round((item.value / max) * 100);
            return {
                name: item.name,
                value: item.value,
                ratio: ratio,
                color: this.pickColor(ratio)
            }
        });
    }

    private pickColor(value: number): string {
        if (value < 25) {
            return "#a8313f";
        } else if (value < 75) {
            return "#cc7f33";
        } else {
            return "#237843";
        }
    }
}

interface IDataBarsPreparedData extends IDataBarsData {
    ratio: number;
    color: string;
}

DataBarsComponent.register();