export interface IDataBarsData {
    name: string;
    value: number
}