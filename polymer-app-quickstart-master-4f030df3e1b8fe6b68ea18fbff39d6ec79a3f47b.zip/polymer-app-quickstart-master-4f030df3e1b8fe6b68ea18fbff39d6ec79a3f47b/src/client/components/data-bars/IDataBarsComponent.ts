import {IDataBarsData} from "./IDataBarsData";
export interface IDataBarsComponent extends HTMLElement {
    header: string;
    data: IDataBarsData[];
}