import * as Promise from "bluebird";
import {EventDispatcher, IEvent} from "strongly-typed-events";

import {injectable} from "inversify";
import {IDataService} from "../../interfaces/dataService/IDataService";
import {ICompanyData} from "../../../../common/model/ICompanyData";
import CompanyGenerator from "../../../../common/utilities/CompanyGenerator";
import {IDynamicDataService} from "../../interfaces/dynamicDataService/IDynamicDataService";

@injectable()
export default class DynamicDataService implements IDynamicDataService<ICompanyData[]> {
    private onDataUpdateDispatcher = new EventDispatcher<IDataService<ICompanyData[]>, ICompanyData[]>();
    private timerHandle: number; //find method to dispose

    private data: ICompanyData[];
    constructor() {
        this.data = CompanyGenerator.generate(5);

    }

    public getData(): Promise<ICompanyData[]> {
        return Promise.resolve(this.data);
    }

    public start() {
        this.timerHandle = window.setInterval(() => {
            this.data.shift();
            this.data.push(CompanyGenerator.generate(1)[0]);
            this.onDataUpdateDispatcher.dispatch(this, this.data);
        }, 1000);
    }

    public stop() {
        window.clearInterval(this.timerHandle);
    }

    public onDataUpdate(): IEvent<IDataService<ICompanyData[]>, ICompanyData[]> {
        return this.onDataUpdateDispatcher.asEvent();
    }
}