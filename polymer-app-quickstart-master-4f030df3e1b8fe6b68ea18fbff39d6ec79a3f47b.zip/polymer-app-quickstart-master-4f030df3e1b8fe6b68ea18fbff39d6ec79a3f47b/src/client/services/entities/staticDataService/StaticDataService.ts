import * as Promise from "bluebird";

import {injectable} from "inversify";
import {IDataService} from "../../interfaces/dataService/IDataService";
import {ICompanyData} from "../../../../common/model/ICompanyData";
import CompanyGenerator from "../../../../common/utilities/CompanyGenerator";

@injectable()
export default class StaticDataService implements IDataService<ICompanyData[]> {
    private data: ICompanyData[];
    constructor() {
        this.data = CompanyGenerator.generate(5);
    }
    public getData(): Promise<ICompanyData[]> {
        return Promise.resolve(this.data);
    }

}