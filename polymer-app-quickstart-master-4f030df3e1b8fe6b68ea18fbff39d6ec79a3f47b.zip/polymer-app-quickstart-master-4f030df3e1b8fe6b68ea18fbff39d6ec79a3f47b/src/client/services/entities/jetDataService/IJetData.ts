export interface IJetData {
    [ric: string]: { [id: string]: any}
}