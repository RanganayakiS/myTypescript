import * as Promise from "bluebird";
import {EventDispatcher, IEvent} from "strongly-typed-events";

import {inject, injectable} from "inversify";
import {IDataService} from "../../interfaces/dataService/IDataService";
import {IJetDataService} from "../../interfaces/jetDataService/IJetDataService";
import {Identifiers} from "../../../constants/Identifiers";
import IJetSubscription = JET.IJetSubscription;
import IJetQuotes = JET.IJetQuotes;
import IEventListenerHandlerOptions = JET.IEventListenerHandlerOptions;
import {IJetQuoteService} from "../../interfaces/jet/jetQuoteService/IJetQuoteService";
import {IJetQuoteSubscription, IRicData} from "../../interfaces/jet/jetQuoteService/IJetQuoteSubscription";
import {IJetData} from "./IJetData";

@injectable()
export default class JetDataService implements IJetDataService<IJetData> {
    private subscription: IJetQuoteSubscription;
    private onDataUpdateDispatcher = new EventDispatcher<IDataService<IJetData>, IJetData>();

    constructor(@inject(Identifiers.JetQuoteService) jetQuoteService: IJetQuoteService) {
        this.subscription = jetQuoteService.create();
        this.subscription.onDataChanged().subscribe((subscription, data) =>this.onSubscriptionDataChanged(subscription, data));
        this.subscription.start();
    }

    public getData(): Promise<IJetData> {
        return Promise.resolve(this.getDataArray());
    }

    public onDataUpdate(): IEvent<IDataService<IJetData>, IJetData> {
        return this.onDataUpdateDispatcher.asEvent();
    }

    public addRic(ric: string): void {
        this.subscription.addRic(ric);
    }

    public addField(field: string): void {
        this.subscription.addField(field);
    }

    public removeRic(ric: string): void {
        this.subscription.removeRic(ric);
    }

    public removeField(field: string): void {
        this.subscription.removeField(field);
    }

    public dispose(): void {
        this.subscription.dispose();
    }

    private onSubscriptionDataChanged(subscription: IJetQuoteSubscription, data: IRicData) {
        this.onDataUpdateDispatcher.dispatch(this, this.getDataArray());
    }

    private getDataArray(): IJetData {
        let ricData = this.subscription.getData();
        return this.subscription.getRics().reduce((acc: IJetData, ric: string) => {
            acc[ric] = ricData[ric].fields;
            return acc;
        }, {});
    }
}