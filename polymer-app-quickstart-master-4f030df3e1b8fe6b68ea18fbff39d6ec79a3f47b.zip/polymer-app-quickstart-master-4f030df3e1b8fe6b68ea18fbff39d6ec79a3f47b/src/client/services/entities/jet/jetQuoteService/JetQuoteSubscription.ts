import {inject, injectable} from "inversify";
import {Identifiers} from "../../../../constants/Identifiers";
import {IJetQuoteSubscription, IRicData} from "../../../interfaces/jet/jetQuoteService/IJetQuoteSubscription";
import {EventDispatcher, IEvent} from "strongly-typed-events";
import {IJetService} from "../../../interfaces/jet/jetService/IJetService";
import IJetQuotes = JET.IJetQuotes;
import IJetSubscription = JET.IJetSubscription;
import IEventListenerHandlerOptions = JET.IEventListenerHandlerOptions;

@injectable()
export default class JetQuoteSubscription implements IJetQuoteSubscription {
    private onDataUpdateDispatcher = new EventDispatcher<IJetQuoteSubscription, IRicData>();

    private jetSubsription: IJetSubscription;

    private rics: string[];
    private fields: string[];
    private ricsSubIds: { [ric: string]: string };

    private ricData: IRicData;

    private isPausedOnDeactivate: boolean;

    private started: boolean;
    private disposed: boolean;


    constructor(@inject(Identifiers.JetService) jetService: IJetService) {
        this.started = false;
        this.disposed = false;

        this.isPausedOnDeactivate = false;

        this.rics = [];
        this.ricsSubIds = {};
        this.fields = [];
        this.ricData = {};
        jetService.getQuotes()
            .then((quotes: IJetQuotes) => {
                if (this.disposed) {
                    return;
                }
                this.jetSubsription = quotes.create();
                this.rics.forEach((ric: string) => {
                    this.ricsSubIds[ric] = this.jetSubsription.addRic(ric);
                });
                this.jetSubsription.addFields(this.fields);
                this.jetSubsription.addEventListener("dataChanged", (options) => this.dataChangeHandler(options));
                if (this.isPausedOnDeactivate) {
                    this.jetSubsription.pauseOnDeactivate(this.isPausedOnDeactivate)
                }
                if (this.started) {
                    this.jetSubsription.start();
                }

            });
    }

    public addRic(ric: string): void {
        if (this.rics.indexOf(ric) == -1) {
            this.rics.push(ric);
            this.addEmptyRicData(ric);
            if (this.jetSubsription) {
                this.ricsSubIds[ric] = this.jetSubsription.addRic(ric);
            }
        }
    }

    public addField(field: string): void {
        if (this.fields.indexOf(field) == -1) {
            this.fields.push(field);
            if (this.jetSubsription) {
                this.jetSubsription.addFields([field]);
            }
        }
    }

    public removeRic(ric: string): void {
        let index = this.rics.indexOf(ric);
        if (index > -1) {
            this.rics.splice(index, 1);
            delete this.ricData[ric];
            if (this.jetSubsription) {
                this.jetSubsription.removeRic(this.ricsSubIds[ric]);
                delete this.ricsSubIds[ric];
            }
        }
    }

    public removeField(field: string): void {
        let index = this.fields.indexOf(field);
        if (index > -1) {
            this.fields.splice(index, 1);
            this.removeFieldFromRicData(field);
            if (this.jetSubsription) {
                this.jetSubsription.removeFields([field]);
            }
        }
    }

    public addRics(rics: string[]): void {
        rics.forEach((ric: string) => {
            if (this.rics.indexOf(ric) == -1) {
                this.rics.push(ric);
                this.addEmptyRicData(ric);
                if (this.jetSubsription) {
                    this.ricsSubIds[ric] = this.jetSubsription.addRic(ric);
                }
            }
        })
    }

    public addFields(fields: string[]): void {
        let newFields: string[] = [];
        fields.forEach((field: string) => {
            if (this.fields.indexOf(field) == -1) {
                newFields.push(field);
            }
        });
        this.fields = [...this.fields,...newFields];
        if (this.jetSubsription) {
            this.jetSubsription.addFields(newFields);
        }
    }

    public removeRics(rics: string[]): void {
        rics.forEach((ric: string) => {
            let index = this.rics.indexOf(ric);
            if (index > -1) {
                this.rics.splice(index, 1);
                delete this.ricData[ric];
                if (this.jetSubsription) {
                    this.jetSubsription.removeRic(this.ricsSubIds[ric]);
                    delete this.ricsSubIds[ric];
                }
            }
        })
    }

    public removeFields(fields: string[]): void {
        let removedFields: string[] = [];
        fields.forEach((field: string) => {
            let index = this.fields.indexOf(field);
            if (index > -1) {
                this.fields.splice(index, 1);
                this.removeFieldFromRicData(field);
                removedFields.push(field);
            }
        });
        if (this.jetSubsription) {
            this.jetSubsription.removeFields(removedFields);
        }
    }

    public pauseOnDeactivate(isPausedOnDeactivate: boolean): void {
        this.isPausedOnDeactivate = isPausedOnDeactivate;
        if (this.jetSubsription) {
            this.jetSubsription.pauseOnDeactivate(isPausedOnDeactivate)
        }
    }

    public start(): void {
        this.started = true;
        if (this.jetSubsription) {
            this.jetSubsription.start();
        }
    }

    public stop(): void {
        this.started = false;
        if (this.jetSubsription) {
            this.jetSubsription.stop();
        }
    }

    public dispose(): void {
        this.stop();
        this.disposed = true;
        if (this.jetSubsription) {
            this.jetSubsription.dispose();
            this.jetSubsription = null;
        }
    }

    public getRics(): string[] {
        return [...this.rics];
    }

    public getFields(): string[] {
        return [...this.fields];
    }

    public getData(): IRicData {
        let data: IRicData = {};
        Object.keys(this.ricData).forEach((ric) => {
            let fields: { [field: string]: number | string } = {};
            Object.keys(this.ricData[ric].fields).forEach((field) => {
                fields[field] = this.ricData[ric].fields[field];
            });

            data[ric] = { fields }
        });
        return data;
    }

    public onDataChanged(): IEvent<IJetQuoteSubscription, IRicData> {
       return this.onDataUpdateDispatcher.asEvent();
    }

    private dataChangeHandler(options: IEventListenerHandlerOptions): void {
        if (this.rics.indexOf(options.ric) == -1) {
            console.warn("Got updated for unsubscribed RIC " + options.ric);
            return;
        }


        let updatedData: IRicData = {};
        updatedData[options.ric] = { fields: {} };
        Object.keys(options.values).forEach((field: string) => {
            updatedData[options.ric].fields[field] = options.values[field];
            this.ricData[options.ric].fields[field] = options.values[field];
        });
        this.onDataUpdateDispatcher.dispatch(this, updatedData);
    }

    private addEmptyRicData(ric: string) {
        this.ricData[ric] = { fields: {} };
    }

    private removeFieldFromRicData(field: string): void {
        Object.keys(this.ricData).forEach((ric: string) => {
            delete this.ricData[ric].fields[field.toUpperCase()];
            delete this.ricData[ric].fields[field.toUpperCase() + "_FORMATTED"];
        });
    }
}