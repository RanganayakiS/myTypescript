import {inject, injectable} from "inversify";

import {IJetQuoteService} from "../../../interfaces/jet/jetQuoteService/IJetQuoteService";
import {IJetQuoteSubscription} from "../../../interfaces/jet/jetQuoteService/IJetQuoteSubscription";
import {Identifiers} from "../../../../constants/Identifiers";

@injectable()
export default class JetQuoteService implements IJetQuoteService{
    @inject(Identifiers.JetQuoteSubscriptionFactory)
    private jetQuoteSubscriptionFactory: () => IJetQuoteSubscription;

    public create(): IJetQuoteSubscription {
        return this.jetQuoteSubscriptionFactory();
    }

}