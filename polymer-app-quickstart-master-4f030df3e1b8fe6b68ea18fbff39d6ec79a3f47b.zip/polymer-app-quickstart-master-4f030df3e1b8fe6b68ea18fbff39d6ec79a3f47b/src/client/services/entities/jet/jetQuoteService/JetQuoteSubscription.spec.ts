import JetQuoteSubscription from "./JetQuoteSubscription";
import IJetQuotes = JET.IJetQuotes;
import IJetSubscription = JET.IJetSubscription;
import {IJetQuoteSubscription, IRicData} from "../../../interfaces/jet/jetQuoteService/IJetQuoteSubscription";
import EventListenerHandler = JET.EventListenerHandler;
import IEventListenerHandlerOptions = JET.IEventListenerHandlerOptions;
describe("JetQuoteSubscription", () => {

    let sendUpdate:EventListenerHandler;

    let subscription: IJetQuoteSubscription = null;
    let jetServiceMock = null;
    let jetQuotesMock = null;
    let jetSubscriptionMock = null;
    beforeEach(() => {
        jetSubscriptionMock = {
            addRic: () => { return; },
            addFields : () => { return; },
            removeRic: () => { return; },
            removeFields: () => { return; },
            addEventListener : () => { return; },
            pauseOnDeactivate : () => { return; },
            start : () => { return; },
            stop : () => { return; },
            dispose : () => { return; }
        };

        jetQuotesMock = {
            create: () => {
                return jetSubscriptionMock;
            }
        };

        spyOn(jetSubscriptionMock, "addRic");
        spyOn(jetSubscriptionMock, "addFields");
        spyOn(jetSubscriptionMock, "removeRic");
        spyOn(jetSubscriptionMock, "removeFields");
        spyOn(jetSubscriptionMock, "addEventListener").and.callFake((event: string, callback:EventListenerHandler) => {
            sendUpdate = callback;
        });
        spyOn(jetSubscriptionMock, "pauseOnDeactivate");
        spyOn(jetSubscriptionMock, "start");
        spyOn(jetSubscriptionMock, "stop");
        spyOn(jetSubscriptionMock, "dispose");

        jetServiceMock = {
            getQuotes: () => {
                return Promise.resolve(jetQuotesMock);
            }
        };
        subscription = new JetQuoteSubscription(jetServiceMock);
    });

    it("Expect subscription to be started", (done) => {
        subscription.start();
        setTimeout(() => {
            expect(jetSubscriptionMock.start).toHaveBeenCalledTimes(1);
            done();
        });
    });

    it("Add RIC", (done) => {
        subscription.addRic("RUB=");
        expect(subscription.getRics().length).toEqual(1);
        expect(subscription.getRics()[0]).toEqual("RUB=");
        expect(subscription.getData()["RUB="]).toBeDefined();
        setTimeout(() => {
            expect(jetSubscriptionMock.addRic).toHaveBeenCalledTimes(1);
            done();
        });
    });

    it("Add field", (done) => {
        subscription.addField("DSPLY_NAME");
        expect(subscription.getFields().length).toEqual(1);
        expect(subscription.getFields()[0]).toEqual("DSPLY_NAME");
        setTimeout(() => {
            expect(jetSubscriptionMock.addFields).toHaveBeenCalledTimes(1);
            done();
        });
    });

    it("Add RICs", (done) => {
        subscription.addRics(["RUB=", "EUR="]);
        expect(subscription.getRics().length).toEqual(2);
        expect(subscription.getRics()[1]).toEqual("EUR=");
        expect(subscription.getData()["EUR="]).toBeDefined();
        expect(subscription.getData()["RUB="]).toBeDefined();
        setTimeout(() => {
            expect(jetSubscriptionMock.addRic).toHaveBeenCalledTimes(2);
            done();
        });
    });

    it("Add fields", (done) => {
        subscription.addFields(["DSPLY_NAME", "PRIMACT_1"]);
        expect(subscription.getFields().length).toEqual(2);
        expect(subscription.getFields()[1]).toEqual("PRIMACT_1");
        setTimeout(() => {
            expect(jetSubscriptionMock.addFields).toHaveBeenCalledTimes(1);
            done();
        });
    });

    it("Receive update", (done) => {
        let updateSpy = jasmine.createSpy("UpdateSpy");
        subscription.addRic("RUB=");
        subscription.addFields(["DSPLY_NAME", "PRIMACT_1"]);
        let options: IEventListenerHandlerOptions = {
            ric: "RUB=",
            subId: "_0_",
            values: {
                "DSPLY_NAME": "RUBLE",
                "PRIMACT_1": 30
            }
        };

        subscription.onDataChanged().subscribe(updateSpy);
        subscription.start();

        setTimeout(() => {
            sendUpdate(options);
            let spyRicData: IRicData = updateSpy.calls.mostRecent().args[1];
            expect(spyRicData["RUB="]).toBeDefined();
            expect(spyRicData["RUB="].fields["DSPLY_NAME"]).toEqual("RUBLE");
            expect(spyRicData["RUB="].fields["PRIMACT_1"]).toEqual(30);
            done();
        });
    });

    it("Receive several updates and store data", (done) => {
        let updateSpy = jasmine.createSpy("UpdateSpy");
        subscription.addRics(["RUB=", "EUR="]);
        subscription.addFields(["DSPLY_NAME", "PRIMACT_1"]);
        let options: IEventListenerHandlerOptions[] = [{
            ric: "RUB=",
            subId: "_0_",
            values: {
                "DSPLY_NAME": "RUBLE",
                "PRIMACT_1": 30
            }
        }, {
            ric: "EUR=",
            subId: "_1_",
            values: {
                "DSPLY_NAME": "EURO",
                "PRIMACT_1": 1.1
            }
        }, {
            ric: "RUB=",
            subId: "_0_",
            values: {
                "PRIMACT_1": 33
            }
        }];

        subscription.onDataChanged().subscribe(updateSpy);
        subscription.start();

        setTimeout(() => {
            options.forEach(sendUpdate);
            expect(updateSpy.calls.count()).toEqual(3);
            let data = subscription.getData();
            expect(data["RUB="].fields["DSPLY_NAME"]).toEqual("RUBLE");
            expect(data["RUB="].fields["PRIMACT_1"]).toEqual(33);
            expect(data["EUR="].fields["DSPLY_NAME"]).toEqual("EURO");
            expect(data["EUR="].fields["PRIMACT_1"]).toEqual(1.1);
            done();
        });
    });

    it("Remove RIC and fields from data", (done) => {
        let updateSpy = jasmine.createSpy("UpdateSpy");
        subscription.addRics(["RUB=", "EUR=", "CHF=", "JPY="]);
        subscription.addFields(["DSPLY_NAME", "PRIMACT_1", "DATA_1", "DATA_2"]);
        let options: IEventListenerHandlerOptions[] = [{
            ric: "RUB=",
            subId: "_0_",
            values: {
                "DSPLY_NAME": "RUBLE",
                "PRIMACT_1": 30,
                "DATA_1": "A",
                "DATA_2": "B"
            }
        }, {
            ric: "CHF=",
            subId: "_2_",
            values: {
                "PRIMACT_1": 1.2,
                "DATA_1": "A",
                "DATA_2": "B"
            }
        },{
            ric: "JPY=",
            subId: "_3_",
            values: {
                "DSPLY_NAME": "EURO",
                "PRIMACT_1": 100,
                "DATA_1": "A",
                "DATA_2": "B"
            }
        },{
            ric: "EUR=",
            subId: "_1_",
            values: {
                "DSPLY_NAME": "EURO",
                "PRIMACT_1": 1.1,
                "DATA_1": "A",
                "DATA_2": "B"
            }
        }, {
            ric: "RUB=",
            subId: "_0_",
            values: {
                "PRIMACT_1": 33
            }
        }];

        subscription.onDataChanged().subscribe(updateSpy);
        subscription.start();

        setTimeout(() => {
            options.forEach(sendUpdate);

            expect(updateSpy.calls.count()).toEqual(5);

            subscription.removeRic("RUB=");
            subscription.removeField("DSPLY_NAME");

            let data = subscription.getData();

            expect(jetSubscriptionMock.removeRic).toHaveBeenCalledTimes(1);
            expect(jetSubscriptionMock.removeFields).toHaveBeenCalledTimes(1);

            expect(subscription.getRics().length).toEqual(3);
            expect(subscription.getFields().length).toEqual(3);

            expect(data["RUB="]).toBeUndefined();
            expect(data["EUR="].fields["DSPLY_NAME"]).toBeUndefined();
            expect(data["EUR="].fields["PRIMACT_1"]).toEqual(1.1);
            expect(data["CHF="].fields["PRIMACT_1"]).toEqual(1.2);
            expect(data["JPY="].fields["PRIMACT_1"]).toEqual(100);

            subscription.getRics().forEach((ric: string) => {
                expect(data[ric].fields["DATA_1"]).toEqual("A");
                expect(data[ric].fields["DATA_2"]).toEqual("B");
            });

            subscription.removeFields(["DATA_1", "DATA_2"]);

            expect(subscription.getFields().length).toEqual(1);
            data = subscription.getData();

            expect(jetSubscriptionMock.removeFields).toHaveBeenCalledTimes(2);
            subscription.getRics().forEach((ric: string) => {
                expect(data[ric].fields["DATA_1"]).toBeUndefined();
                expect(data[ric].fields["DATA_2"]).toBeUndefined();
            });

            subscription.removeRics(["EUR=", "JPY="]);

            expect(subscription.getRics().length).toEqual(1);
            data = subscription.getData();

            expect(jetSubscriptionMock.removeRic).toHaveBeenCalledTimes(3);
            expect(data["EUR="]).toBeUndefined();
            expect(data["JPY="]).toBeUndefined();
            expect(data["CHF="]).toBeDefined();

            done();
        });
    });

});