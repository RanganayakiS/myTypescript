import * as Promise from "bluebird";
import {inject, injectable} from "inversify";
import {Identifiers} from "../../../../constants/Identifiers";
import {IJetService} from "../../../interfaces/jet/jetService/IJetService";
import {IJetArchiveService} from "../../../interfaces/jet/jetArchiveService/IJetArchiveService"

@injectable()
export default class JetArchiveService implements IJetArchiveService {
    @inject(Identifiers.JetService) 
    private jetService: IJetService;

    public getAllKeys(): Promise<string[]> {
        return this.jetService.getArchive()
            .then((archive) => {
                return archive.getAllKeys();
            })
    }

    public get<T>(key: string, defaultValue?: T): Promise<T> {
        return this.jetService.getArchive()
            .then((archive) => {
                return JSON.parse(archive.get(key, JSON.stringify(defaultValue)));
            })
    }

    public put<T>(key: string, item?: T): Promise<boolean> {
        return this.jetService.getArchive()
            .then((archive) => {
                return archive.put(key, JSON.stringify(item));
            })
    }

    public clear(): Promise<void> {
        return this.jetService.getArchive()
            .then((archive) => {
                return archive.clear();
            })
    }
}