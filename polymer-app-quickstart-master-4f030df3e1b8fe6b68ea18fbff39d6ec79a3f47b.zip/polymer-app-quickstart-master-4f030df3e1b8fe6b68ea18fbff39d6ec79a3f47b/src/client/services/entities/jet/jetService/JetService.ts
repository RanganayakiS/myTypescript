import * as Promise from "bluebird";
import {Resolver} from "bluebird";
import {injectable} from "inversify";

import {JetHelper} from "../../../../helpers/JetHelper/JetHelper";
import {IJetService} from "../../../interfaces/jet/jetService/IJetService";
import {ISignal, SignalDispatcher} from "strongly-typed-events";
import IJetQuotes = JET.IJetQuotes;
import IJetArchive = JET.IJetArchive;
import IJetSettings = JET.IJetSettings;
import IJetApi = JET.IJetApi;

interface IDeferred<T> {
    resolve: (value: T) => void;
    reject: (reason: any) => void;
}

@injectable()
export default class JetService implements IJetService {
    private onJetLoadDispatcher = new SignalDispatcher();
    private onJetLoadFailedDispatcher = new SignalDispatcher();

    //private quotesDeferred: Resolver<IJetQuotes>[] = []; // Obsolete specification
    private quotesDeferred: IDeferred<IJetQuotes>[] = [];

    private jetApi: IJetApi;
    
    private jet: Promise<IJetApi>;

    constructor () {
        this.jetApi = JetHelper.getJet();

        this.jet = new Promise<IJetApi>((resolve, reject) => {
            if (!this.jetApi) {
                console.warn("JET is unavailable as global variable");
                reject(new Error("JET is unavailable as global variable"));
            }
            this.jetApi.onLoad(() => {
                console.info("JET is ready");
                this.onJetLoadDispatcher.dispatch();
                resolve(this.jetApi);

            }, ["AppHits", "Settings", "Quotes2"]);
            this.jetApi.onLoadFailed(() => {
                console.warn("JET loading failed");
                this.onJetLoadFailedDispatcher.dispatch();
                reject(new Error("JET failed to load"));
                
            });
        });
    }

    public getQuotes(): Promise<IJetQuotes> {
        return this.jet
        .catch((e: Error) => {
            console.warn("JET Quotes is unavailable");
            throw e;
        })
        .then((jet) => {
            return jet.Quotes2;
        });
    }

    public getArchive(): Promise<IJetArchive> {
        return this.jet
        .catch((e: Error) => {
            console.warn("JET Archive is unavailable");
            throw e;
        })
        .then((jet) => {
            return jet.Archive;
        });
    }

    public getSettings(): Promise<IJetSettings> {
        return this.jet
        .catch((e: Error) => {
            console.warn("JET Settings is unavailable");
            throw e;
        })
        .then((jet) => {
            return jet.Settings;
        });
    }

    public appHit(appName: string, subProduct: string, feature: string): Promise<void> {
        return this.jet
        .then((jet) => {
            jet.appHit(appName, subProduct, feature);
        });
        
    }

    public init(id: string, title: string): void {
        if (this.jetApi) {
            this.jetApi.init({  
                ID: id,
                Title: title
            })
        }
    }

    public onLoad(): ISignal {
        return this.onJetLoadDispatcher.asEvent();
    }

    public onLoadFailed(): ISignal {
        return this.onJetLoadFailedDispatcher.asEvent();
    }
}