import * as Promise from "bluebird";
import {inject, injectable} from "inversify";
import {Identifiers} from "../../../../constants/Identifiers";
import {IJetService} from "../../../interfaces/jet/jetService/IJetService";
import {IJetSettingsService} from "../../../interfaces/jet/jetSettingsService/IJetSettingsService"

@injectable()
export default class JetSettingsService implements IJetSettingsService {
    @inject(Identifiers.JetService) 
    private jetService: IJetService;

    public read(providerName: string, settingName: string, expandValue?: boolean): Promise<string> {
        return this.jetService.getSettings()
            .then((settings) => {
                return new Promise<string>((resolve, reject) => {
                    settings.read(resolve, { providerName, settingName }, this.wrapReject(reject));
                });
            })
    }
    
    public write(providerName: string, settingName: string, settingValue: string): void {
        this.jetService.getSettings()
            .then((settings) => {
                settings.write({ providerName, settingName, settingValue });
            });
    }

    private wrapReject(reject: (e: Error) => void) {
        return (msg: string) => reject(new Error(msg));
    }

}