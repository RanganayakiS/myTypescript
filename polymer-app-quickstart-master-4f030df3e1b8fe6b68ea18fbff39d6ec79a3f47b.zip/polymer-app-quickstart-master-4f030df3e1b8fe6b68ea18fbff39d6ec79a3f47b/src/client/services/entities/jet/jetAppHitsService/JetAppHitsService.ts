import * as Promise from "bluebird";
import {inject, injectable} from "inversify";
import {Identifiers} from "../../../../constants/Identifiers";
import {IJetService} from "../../../interfaces/jet/jetService/IJetService";
import {IJetAppHitsService} from "../../../interfaces/jet/jetAppHitsService/IJetAppHitsService"

@injectable()
export default class JetAppHitsService implements IJetAppHitsService {
    @inject(Identifiers.JetService) 
    private jetService: IJetService;

    public appHit(appName: string, subProduct: string, feature: string): void {
        this.jetService.appHit(appName, subProduct, feature)
            .catch((e) => {
                console.log(`Unable to register JET AppHit: ${appName} ${subProduct} ${feature}`);
            });
    }
}