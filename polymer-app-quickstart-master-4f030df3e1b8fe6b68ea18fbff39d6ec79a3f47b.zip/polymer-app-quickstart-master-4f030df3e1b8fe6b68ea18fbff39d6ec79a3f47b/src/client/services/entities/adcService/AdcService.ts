import * as Promise from "bluebird";
import {injectable} from "inversify";
import {IAdcService} from "../../interfaces/adcService/IAdcService";
import {IAdcServiceResponse} from "../../interfaces/adcService/IAdcServiceResponse";
import IUdfAdcRequestData = UDF.IUdfAdcRequestData;
import IUdfBatchRequest = UDF.IUdfBatchRequest;
import HttpHelper from "../../../helpers/HttpHelper/HttpHelper";
import IUdfAdcResponseData = UDF.IUdfAdcResponseData;
import {Globals} from "../../../../common/constants/Globals";

const udfMethod = "Snapshot";

@injectable()
export default class AdcService implements IAdcService {
    public getData(symbols: string[], formulas: string[]): Promise<IAdcServiceResponse> {
        let requests: IUdfAdcRequestData[] = formulas.map((field) => {
            return {
                ProductID: Globals.ApplicationName,
                Tickers: symbols,
                Formulas: [field]
            };
        });
        let request: IUdfBatchRequest = {
            Batch: {
                Entities: requests.map((r, id) => {
                   return {
                       id: id.toString(),
                       E: udfMethod,
                       W: r
                   };
                })
            }
        };

        let fieldNames = formulas.reduce((acc, f, index) => {
            acc[index.toString()] = f;
            return acc;
        }, {});

        return HttpHelper.post<IUdfAdcResponseData[]>(Globals.UdfServiceUrl, request)
            .then((data) => {
                let response: IAdcServiceResponse = {};
                Object.keys(data).forEach((id) => {
                   let fieldData = data[id].r;
                   if (fieldData && fieldData.length > 1) {
                       let subfieldIds = fieldData[0].v;
                       for (let i = 1; i < fieldData.length; i++) {
                           let rowData =  fieldData[i].v;
                           let responseData;

                           if (!response[rowData[0]]) {
                               responseData = {};
                               response[rowData[0]] = responseData;
                           } else {
                               responseData = response[rowData[0]]
                           }

                           let responseFieldData = {};
                           if (!responseData[fieldNames[id]]) {
                               responseData[fieldNames[id]] = [responseFieldData];
                           } else {
                               responseData[fieldNames[id]].push(responseFieldData);
                           }

                           for (let j = 1; j < fieldData[i].v.length; j++) {
                               responseFieldData[subfieldIds[j]] = rowData[j]
                           }

                           responseFieldData["_default"] = rowData[rowData.length - 1];

                       }
                   }
                });
                return response;
            });
    }

}