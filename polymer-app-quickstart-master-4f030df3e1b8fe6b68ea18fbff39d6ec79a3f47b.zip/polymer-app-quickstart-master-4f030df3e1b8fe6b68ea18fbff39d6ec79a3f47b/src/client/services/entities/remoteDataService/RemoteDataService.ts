import * as Promise from "bluebird";

import IAppServerPayload = AppServer.IAppServerPayload;
import {injectable} from "inversify";
import {IDataService} from "../../interfaces/dataService/IDataService";
import {ICompanyData} from "../../../../common/model/ICompanyData";
import HttpHelper from "../../../helpers/HttpHelper/HttpHelper";
import {ICompanyDataDto} from "../../../../common/dto/ICompanyDataDto";

const headers = {
    "Content-Type": "application/json",
    "Accept": "application/json"
};

@injectable()
export default class RemoteDataService implements IDataService<ICompanyData[]> {
    constructor() {
    }

    public getData(): Promise<ICompanyData[]> {
        let payload: IAppServerPayload<any> = {
            action: "sampleDataRequest"
        };
        return HttpHelper.post<ICompanyDataDto[]>("service/SampleService", payload, headers)
            .then((dataDto: ICompanyDataDto[]) => {
                return dataDto.map((entry: ICompanyDataDto) => {
                    return {
                        name: entry.name,
                        date: new Date(entry.date),
                        value: entry.value,
                        description: entry.description
                    };
                })
            });
    }
}