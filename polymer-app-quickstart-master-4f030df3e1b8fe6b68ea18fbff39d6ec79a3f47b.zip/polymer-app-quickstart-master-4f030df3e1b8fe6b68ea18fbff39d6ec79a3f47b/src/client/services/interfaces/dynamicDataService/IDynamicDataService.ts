import {IDataService} from "../dataService/IDataService";
import {IEvent} from "strongly-typed-events";
export interface IDynamicDataService<T> extends IDataService<T> {
    onDataUpdate(): IEvent<IDynamicDataService<T>, T>
    start(): void
    stop(): void
}