import * as Promise from "bluebird";

export interface IDataService<T> {
    getData(): Promise<T>
}