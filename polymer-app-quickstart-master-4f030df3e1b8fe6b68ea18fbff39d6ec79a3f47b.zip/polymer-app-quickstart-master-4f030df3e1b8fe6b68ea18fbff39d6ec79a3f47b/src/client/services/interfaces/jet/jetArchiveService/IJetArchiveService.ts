import * as Promise from "bluebird";

export interface IJetArchiveService {
    getAllKeys(): Promise<string[]>;
    get<T>(key: string, defaultValue?: T): Promise<T>;
    put<T>(key: string, item?: T): Promise<boolean>;
    clear(): Promise<void>;
}