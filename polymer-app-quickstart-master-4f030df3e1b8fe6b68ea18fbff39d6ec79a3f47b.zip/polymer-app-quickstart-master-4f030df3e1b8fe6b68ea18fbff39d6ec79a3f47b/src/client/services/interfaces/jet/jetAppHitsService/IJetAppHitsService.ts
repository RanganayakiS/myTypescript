export interface IJetAppHitsService {
    appHit(appName: string, subProduct: string, feature: string): void;
}