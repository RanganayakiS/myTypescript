import {IJetQuoteSubscription} from "./IJetQuoteSubscription";
export interface IJetQuoteService {
    create(): IJetQuoteSubscription
}