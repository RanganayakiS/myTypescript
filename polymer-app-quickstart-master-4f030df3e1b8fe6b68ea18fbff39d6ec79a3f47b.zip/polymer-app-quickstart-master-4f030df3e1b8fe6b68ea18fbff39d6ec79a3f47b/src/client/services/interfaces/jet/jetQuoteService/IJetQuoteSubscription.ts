import {IEvent} from "strongly-typed-events";
export interface IRicData {
    [ric: string]: {
        fields: { [field: string]: number | string }
    }
}

export interface IJetQuoteSubscription {
    addRic(ric: string): void;
    addField(field: string): void;
    removeRic(ric: string): void;
    removeField(field: string): void;
    addRics(ric: string[]): void;
    addFields(fields: string[]): void;
    removeRics(rics: string[]): void;
    removeFields(fields: string[]): void;
    pauseOnDeactivate(isPausedOnDeactivate: boolean): void;
    start(): void;
    stop(): void;
    dispose(): void;
    getRics(): string[];
    getFields(): string[];

    getData(): IRicData;
    onDataChanged(): IEvent<IJetQuoteSubscription, IRicData>
}