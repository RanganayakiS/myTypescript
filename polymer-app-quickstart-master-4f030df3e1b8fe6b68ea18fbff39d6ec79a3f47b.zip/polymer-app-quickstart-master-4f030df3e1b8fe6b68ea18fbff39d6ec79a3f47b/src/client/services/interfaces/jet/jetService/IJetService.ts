import * as Promise from "bluebird";
import { ISignal } from "strongly-typed-events";
import IJetQuotes = JET.IJetQuotes;
import IJetArchive = JET.IJetArchive;
import IJetSettings = JET.IJetSettings;

export interface IJetService {
    onLoad(): ISignal
    onLoadFailed(): ISignal
    getArchive(): Promise<IJetArchive>
    getSettings(): Promise<IJetSettings>
    getQuotes(): Promise<IJetQuotes>
    appHit(appName: string, subProduct: string, feature: string): Promise<void>
    init(id: string, title: string)
}