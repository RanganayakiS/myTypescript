import * as Promise from "bluebird";

export interface IJetSettingsService {
    read(providerName: string, settingName: string, expandValue?: boolean): Promise<string>
    write(providerName: string, settingName: string, settingValue: string): void
}