import {IDataService} from "../dataService/IDataService";
import {IEvent} from "strongly-typed-events";
export interface IJetDataService<T> extends IDataService<T> {
    addRic(ric: string);
    addField(fields: string);
    removeRic(ric: string);
    removeField(fields: string);
    dispose(): void;
    onDataUpdate(): IEvent<IJetDataService<T>, T>;
}