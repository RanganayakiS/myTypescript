export interface IAdcServiceResponse {
    [ric: string]: {
        [field: string]: {
            [subfield: string]: string
        }[]
    }
}