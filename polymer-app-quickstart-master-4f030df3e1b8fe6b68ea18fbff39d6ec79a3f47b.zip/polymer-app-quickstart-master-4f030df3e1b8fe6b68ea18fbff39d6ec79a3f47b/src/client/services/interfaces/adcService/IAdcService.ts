import * as Promise from "bluebird";
import {IAdcServiceResponse} from "./IAdcServiceResponse";
export interface IAdcService {
    getData(symbols: string[], formulas: string[]): Promise<IAdcServiceResponse>;
}