// for 3rd party libraries
/// <reference path="../bower_components/polymer-ts/polymer-ts.d.ts" />
import "reflect-metadata";
import "strongly-typed-events";
import "bluebird";
import "moment";
import "numeral";

import * as Promise from "bluebird";

//JET services compatability
(<any>window).Q = {
    defer: () => {
        let deferred = {};
        let promise = new Promise(function(resolve, reject) {
            deferred["resolve"] = resolve;
            deferred["reject"]  = reject;
        });
        deferred["promise"] = promise;
        return deferred;
        },
    all: Promise.all,
    resolve: Promise.resolve,
    reject: Promise.reject
};

import "../bower_components/jet-api/dist/JET.js";
import "../bower_components/jet-plugin-quotes2/src/jet-plugin-quotes2.js";
import "../bower_components/jet-plugin-apphits/src/jet-plugin-apphits.js";
import "../bower_components/jet-plugin-settings/src/jet-plugin-settings.js";

// Web components bundle
(<any>window).uifr = {
    allowedThemes: {}
};

(<any>window).UIFR_Cache = require("exports-loader?UIFR_Cache!../bower_components/jet-service-adapter/Classes/Cache.js");
(<any>window).UIFR_Message = require("exports-loader?UIFR_Message!../bower_components/jet-service-adapter/Classes/Message.js");
(<any>window).UIFR_Request = require("exports-loader?UIFR_Request!../bower_components/jet-service-adapter/Classes/Request.js");
(<any>window).UIFR_Service = require("exports-loader?UIFR_Service!../bower_components/jet-service-adapter/Classes/Service.js");

import "../bower_components/polymer-ts/polymer-ts.min.js"
import "./vendor-elements.html";