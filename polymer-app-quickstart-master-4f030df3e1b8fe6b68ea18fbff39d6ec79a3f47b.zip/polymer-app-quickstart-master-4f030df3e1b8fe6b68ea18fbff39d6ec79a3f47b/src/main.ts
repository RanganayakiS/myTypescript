import { container } from "./client/config/inversify.config";
import { Identifiers } from "./client/constants/Identifiers";
import "./elements.html";

let app = container.get<IAppBootstrapper>(Identifiers.AppBootstrapper);
app.run();