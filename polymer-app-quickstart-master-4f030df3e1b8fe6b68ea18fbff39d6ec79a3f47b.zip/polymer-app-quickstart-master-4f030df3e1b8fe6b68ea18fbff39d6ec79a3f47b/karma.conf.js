// Karma configuration
process.env.NODE_ENV = 'test';
const webpackConfig = require("./webpack.config.js");

module.exports = function (config) {
    config.set({
        basePath: '',
        frameworks: ['jasmine'],
        files: [
            //Polyfills
            'node_modules/babel-polyfill/dist/polyfill.js',

            './src/**/*.spec.ts'
        ],
        preprocessors: {
            './src/client/**/*.spec.ts': ['webpack', 'sourcemap']
        },
        reporters: ['spec'], // 'coverage'
        port: 9876,
        logLevel: config.LOG_INFO,
        autoWatch: false,
        singleRun: true,
        browsers: ['PhantomJS'],
        plugins: [
            'karma-jasmine',
            'karma-webpack',
            'karma-spec-reporter',
            'karma-coverage',
            'karma-phantomjs-launcher',
            'karma-sourcemap-loader',
            'karma-chrome-launcher'
        ],
        // coverageReporter: {
        //     dir : '__coverage/'
        // },
        webpack: webpackConfig,
        webpackMiddleware: {
            noInfo:true
        }
    })
};
